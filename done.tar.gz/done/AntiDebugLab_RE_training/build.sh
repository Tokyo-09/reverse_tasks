#!/usr/bin/env bash
set -e

CXX="${CXX:-x86_64-w64-mingw32-g++}"

"$CXX" -std=c++17 -O0 -s \
    -static-libgcc -static-libstdc++ \
    challenge.cpp -o AntiDebugLab.exe

"$CXX" -std=c++17 -O0 -g \
    -static-libgcc -static-libstdc++ \
    challenge.cpp -o AntiDebugLab_debug.exe

echo "[+] Build complete"
file AntiDebugLab.exe AntiDebugLab_debug.exe
