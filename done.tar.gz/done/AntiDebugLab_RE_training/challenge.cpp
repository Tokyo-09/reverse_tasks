#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <iostream>

static bool api_debugger_check()
{
    return IsDebuggerPresent() != 0;
}

#if defined(__GNUC__) && defined(__x86_64__)
static bool peb_check_gcc_x64()
{
    void* peb = nullptr;
    asm volatile ("movq %%gs:0x60, %0" : "=r"(peb));
    BYTE beingDebugged = *reinterpret_cast<BYTE*>(
        reinterpret_cast<unsigned char*>(peb) + 0x2);
    return beingDebugged != 0;
}
#else
static bool peb_check_gcc_x64()
{
    return false;
}
#endif

static bool debugger_detected()
{
    if (api_debugger_check())
        return true;

    if (peb_check_gcc_x64())
        return true;

    return false;
}

static void print_result(bool detected)
{
    if (detected)
    {
        std::cout << "[-] Debugger detected\n";
        std::cout << "[-] Challenge locked\n";
    }
    else
    {
        std::cout << "[+] Environment OK\n";
        std::cout << "[+] Challenge unlocked\n";
    }
}

int main()
{
    std::cout << "========================\n";
    std::cout << "      AntiDebugLab\n";
    std::cout << "========================\n\n";

    std::cout << "Checking environment...\n\n";

    const bool detected = debugger_detected();
    print_result(detected);

    return detected ? 1 : 0;
}
