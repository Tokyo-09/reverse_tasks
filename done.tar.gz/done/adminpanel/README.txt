# AdminPanel RE Training

Package contents:

- AdminPanel.cpp
- README_STUDENT.txt
- SOLUTION_TEACHER.txt
- build_mingw.bat
- BUILD_NOTE.txt

This exercise is intentionally local and benign.

It contains no:

- cryptography
- obfuscation
- keygen
- network communication
- persistence
- process injection
- credential collection
- exploitation

The challenge is based entirely on understanding control flow and program
state in a small native Win32 GUI application.

## Building

On Windows with MinGW-w64 installed:

    build_mingw.bat

For a harder build, edit the script and change:

    -O0

to:

    -O2

The optimized version may produce substantially different assembly.
