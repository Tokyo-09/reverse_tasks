# AdminPanel — Control Flow Reverse Engineering Lab

## Difficulty

Beginner / intermediate.

Recommended solving time: 30–60 minutes.

---

## Scenario

You have received a small Windows GUI application called `AdminPanel.exe`.

The application contains three account states:

- Not authenticated
- User
- Administrator

There is also an `Admin Panel` button.

Your objective is to make the application reach the Administrator state
and enable the Admin Panel.

---

## What you receive

Only:

    AdminPanel.exe

Do not use the source code while solving.

---

## Rules

Allowed:

- Ghidra
- IDA
- x64dbg
- debugger
- disassembler
- binary patching

Not required:

- brute force
- keygen
- cryptography
- XOR
- networking
- exploitation

---

## Initial investigation

Run the application.

Try:

    operator

and:

    admin

Observe the difference.

The application gives you useful information through its GUI, but the GUI
does not directly tell you why Administrator access is unavailable.

---

## Objectives

### 1. Find the login path

Identify the code executed when the Login button is pressed.

### 2. Find the access-level function

Determine how the program converts a username into an access level.

Questions:

- What value represents `USER`?
- What value represents `ADMIN`?
- What value represents `NONE`?

### 3. Trace the Administrator branch

Find the code that handles the Administrator state.

Do not stop after finding the string:

    Status: Administrator

Follow the control flow backwards and forwards.

### 4. Find the second guard

The Administrator state is subject to another condition.

Find it.

Explain why the condition currently prevents the Admin Panel from being
enabled.

### 5. Patch the binary

Make the smallest reasonable patch that allows:

    admin

to produce:

    Status: Administrator

and enables:

    Admin Panel

### 6. Verify

After patching:

    Username: admin

Click:

    Login

Expected:

    Status: Administrator

and:

    Admin Panel

must be enabled.

---

## Bonus challenge

Find at least two different patches that produce the desired behavior.

For each patch explain:

- which instruction/branch was changed;
- what the original branch did;
- what the patched branch does;
- whether the patch changes program state or only the GUI.

---

## Deliverable

Submit:

1. patched executable;
2. screenshot of the final Administrator state;
3. a short explanation of the control flow;
4. addresses/instructions changed by your patch.

---

## Instructor hint levels

Hint 1:

    Start with the visible strings.

Hint 2:

    Look at XREFs to "Status: Administrator".

Hint 3:

    There are two separate decisions between the username and the button.

Hint 4:

    Pay attention to the integer returned by the access-level function.

Hint 5:

    The Admin Panel has its own guard after Administrator has already
    been established.
