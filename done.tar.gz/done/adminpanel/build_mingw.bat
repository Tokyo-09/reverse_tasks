@echo off
where g++ >nul 2>nul
if errorlevel 1 (
    echo MinGW-w64 g++ was not found in PATH.
    echo Install MinGW-w64 and add its bin directory to PATH.
    pause
    exit /b 1
)

echo Building AdminPanel.exe...
g++ -std=c++17 -O0 -s -municode AdminPanel.cpp -o AdminPanel.exe -mwindows -static-libgcc -static-libstdc++

if errorlevel 1 (
    echo Build failed.
    pause
    exit /b 1
)

echo.
echo Build successful.
echo Output: AdminPanel.exe
pause
