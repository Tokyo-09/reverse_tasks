#define UNICODE
#define _UNICODE

#include <windows.h>
#include <string>

static HWND g_username;
static HWND g_status;
static HWND g_userPanel;
static HWND g_adminPanel;

enum AccessLevel {
    ACCESS_NONE = 0,
    ACCESS_USER = 1,
    ACCESS_ADMIN = 2
};

static int GetAccessLevel(const std::wstring& username)
{
    if (username == L"operator")
        return ACCESS_USER;

    if (username == L"admin")
        return ACCESS_ADMIN;

    return ACCESS_NONE;
}

static bool CanOpenAdminPanel(int accessLevel)
{
    // Second control-flow guard.
    // This is intentionally false in the training build.
    bool maintenanceMode = false;

    if (accessLevel != ACCESS_ADMIN)
        return false;

    if (maintenanceMode)
        return false;

    return true;
}

static std::wstring ReadUsername()
{
    int length = GetWindowTextLengthW(g_username);
    std::wstring username(length, L'\0');

    if (length > 0)
        GetWindowTextW(g_username, username.data(), length + 1);

    return username;
}

static void UpdateStatus()
{
    const std::wstring username = ReadUsername();
    const int accessLevel = GetAccessLevel(username);

    EnableWindow(g_userPanel, FALSE);
    EnableWindow(g_adminPanel, FALSE);

    if (accessLevel == ACCESS_ADMIN) {
        SetWindowTextW(g_status, L"Status: Administrator");

        if (CanOpenAdminPanel(accessLevel)) {
            EnableWindow(g_adminPanel, TRUE);
            EnableWindow(g_userPanel, FALSE);
        }
    }
    else if (accessLevel == ACCESS_USER) {
        SetWindowTextW(g_status, L"Status: User");
        EnableWindow(g_userPanel, TRUE);
    }
    else {
        SetWindowTextW(g_status, L"Status: Not authenticated");
    }
}

static void ShowUserPanel()
{
    MessageBoxW(
        nullptr,
        L"User Panel\n\n"
        L"Account type: standard user\n"
        L"Training application",
        L"AdminPanel",
        MB_OK | MB_ICONINFORMATION
    );
}

static void ShowAdminPanel()
{
    MessageBoxW(
        nullptr,
        L"ADMIN PANEL\n\n"
        L"Access level: ADMIN\n"
        L"System configuration: available\n\n"
        L"Training objective completed.",
        L"AdminPanel",
        MB_OK | MB_ICONINFORMATION
    );
}

LRESULT CALLBACK WndProc(
    HWND hwnd,
    UINT message,
    WPARAM wParam,
    LPARAM lParam)
{
    switch (message) {
    case WM_CREATE:
        CreateWindowW(
            L"STATIC",
            L"Admin Control Panel — RE training build",
            WS_CHILD | WS_VISIBLE,
            20, 15, 410, 25,
            hwnd, nullptr, nullptr, nullptr
        );

        CreateWindowW(
            L"STATIC",
            L"Username:",
            WS_CHILD | WS_VISIBLE,
            20, 60, 80, 20,
            hwnd, nullptr, nullptr, nullptr
        );

        g_username = CreateWindowW(
            L"EDIT",
            L"",
            WS_CHILD | WS_VISIBLE | WS_BORDER | ES_AUTOHSCROLL,
            100, 57, 220, 25,
            hwnd, nullptr, nullptr, nullptr
        );

        CreateWindowW(
            L"BUTTON",
            L"Login",
            WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
            330, 57, 100, 25,
            hwnd, (HMENU)1001, nullptr, nullptr
        );

        g_status = CreateWindowW(
            L"STATIC",
            L"Status: Not authenticated",
            WS_CHILD | WS_VISIBLE,
            20, 105, 410, 25,
            hwnd, nullptr, nullptr, nullptr
        );

        g_userPanel = CreateWindowW(
            L"BUTTON",
            L"User Panel",
            WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
            20, 145, 150, 32,
            hwnd, (HMENU)1002, nullptr, nullptr
        );

        g_adminPanel = CreateWindowW(
            L"BUTTON",
            L"Admin Panel",
            WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
            190, 145, 150, 32,
            hwnd, (HMENU)1003, nullptr, nullptr
        );

        EnableWindow(g_userPanel, FALSE);
        EnableWindow(g_adminPanel, FALSE);
        break;

    case WM_COMMAND:
        switch (LOWORD(wParam)) {
        case 1001:
            UpdateStatus();
            break;

        case 1002:
            ShowUserPanel();
            break;

        case 1003:
            ShowAdminPanel();
            break;
        }
        break;

    case WM_DESTROY:
        PostQuitMessage(0);
        break;
    }

    return DefWindowProcW(hwnd, message, wParam, lParam);
}

int WINAPI wWinMain(
    HINSTANCE hInstance,
    HINSTANCE,
    PWSTR,
    int nCmdShow)
{
    const wchar_t CLASS_NAME[] = L"AdminPanelTraining";

    WNDCLASSW wc{};
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = CLASS_NAME;
    wc.hCursor = LoadCursorW(nullptr, IDC_ARROW);
    wc.hbrBackground =
        reinterpret_cast<HBRUSH>(COLOR_WINDOW + 1);

    RegisterClassW(&wc);

    HWND hwnd = CreateWindowW(
        CLASS_NAME,
        L"AdminPanel",
        WS_OVERLAPPED |
        WS_CAPTION |
        WS_SYSMENU |
        WS_MINIMIZEBOX,
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        470,
        230,
        nullptr,
        nullptr,
        hInstance,
        nullptr
    );

    if (!hwnd)
        return 0;

    ShowWindow(hwnd, nCmdShow);
    UpdateWindow(hwnd);

    MSG message{};

    while (GetMessageW(&message, nullptr, 0, 0) > 0) {
        TranslateMessage(&message);
        DispatchMessageW(&message);
    }

    return 0;
}
