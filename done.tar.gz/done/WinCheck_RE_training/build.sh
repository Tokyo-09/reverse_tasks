#!/usr/bin/env bash
set -e

CXX="${CXX:-x86_64-w64-mingw32-g++}"

echo "[*] Compiler: $CXX"

"$CXX" -std=c++17 -O0 -s -static-libgcc -static-libstdc++ \
    challenge.cpp -o WinCheck.exe

"$CXX" -std=c++17 -O0 -g \
    challenge.cpp -o WinCheck_debug.exe

echo "[+] Built:"
file WinCheck.exe WinCheck_debug.exe
