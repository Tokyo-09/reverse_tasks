const { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
        Header, Footer, AlignmentType, HeadingLevel, BorderStyle, WidthType,
        ShadingType, PageNumber, LevelFormat } = require("docx");
const fs = require("fs");

const A4 = { width: 11906, height: 16838 };
const MARGIN = 1080;
const CW = A4.width - MARGIN * 2; // 9746

const border = { style: BorderStyle.SINGLE, size: 4, color: "CCCCCC" };
const borders = { top: border, bottom: border, left: border, right: border };
const headFill = "1F3A5F";
const altFill = "F4F7FB";

const styles = {
  default: { document: { run: { font: "Arial", size: 22 } } },
  paragraphStyles: [
    { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
      run: { size: 36, bold: true, font: "Arial", color: "1F3A5F" },
      paragraph: { spacing: { before: 280, after: 160 }, outlineLevel: 0 } },
    { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
      run: { size: 28, bold: true, font: "Arial", color: "2C5282" },
      paragraph: { spacing: { before: 240, after: 120 }, outlineLevel: 1 } },
    { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true,
      run: { size: 24, bold: true, font: "Arial", color: "2C5282" },
      paragraph: { spacing: { before: 180, after: 80 }, outlineLevel: 2 } },
  ],
};

const numbering = {
  config: [
    { reference: "bullets", levels: [{ level: 0, format: LevelFormat.BULLET, text: "•",
      alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
    { reference: "nums", levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.",
      alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
  ],
};

function p(text, opts = {}) {
  return new Paragraph({
    spacing: { after: 120, line: 276 },
    ...opts,
    children: [new TextRun({ text, font: "Arial", size: opts.size || 22, bold: opts.bold, italics: opts.italics, color: opts.color })],
  });
}
function h1(t) { return new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun(t)] }); }
function h2(t) { return new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun(t)] }); }
function h3(t) { return new Paragraph({ heading: HeadingLevel.HEADING_3, children: [new TextRun(t)] }); }
function bullet(t) {
  return new Paragraph({ numbering: { reference: "bullets", level: 0 }, spacing: { after: 60 },
    children: [new TextRun({ text: t, font: "Arial", size: 22 })] });
}
function num(t) {
  return new Paragraph({ numbering: { reference: "nums", level: 0 }, spacing: { after: 60 },
    children: [new TextRun({ text: t, font: "Arial", size: 22 })] });
}
function code(t) {
  return new Paragraph({
    spacing: { after: 80 },
    shading: { type: ShadingType.CLEAR, fill: "F3F4F6" },
    children: [new TextRun({ text: t, font: "Consolas", size: 18 })],
  });
}
function note(t) {
  return new Paragraph({
    spacing: { before: 80, after: 160 },
    shading: { type: ShadingType.CLEAR, fill: "FFF7ED" },
    children: [new TextRun({ text: t, font: "Arial", size: 20, italics: true, color: "9A3412" })],
  });
}

function cell(text, width, opts = {}) {
  return new TableCell({
    borders,
    width: { size: width, type: WidthType.DXA },
    shading: { fill: opts.fill || "FFFFFF", type: ShadingType.CLEAR },
    margins: { top: 60, bottom: 60, left: 80, right: 80 },
    children: [new Paragraph({
      children: [new TextRun({
        text, font: "Arial", size: opts.size || 18,
        bold: !!opts.bold, color: opts.color || "111111",
      })],
    })],
  });
}

function table(headers, rows, widths) {
  const head = new TableRow({
    children: headers.map((h, i) => cell(h, widths[i], { fill: headFill, bold: true, color: "FFFFFF" })),
  });
  const body = rows.map((r, ri) => new TableRow({
    children: r.map((c, i) => cell(c, widths[i], { fill: ri % 2 ? altFill : "FFFFFF" })),
  }));
  return new Table({
    width: { size: CW, type: WidthType.DXA },
    columnWidths: widths,
    rows: [head, ...body],
  });
}

function header(title) {
  return new Header({ children: [new Paragraph({
    border: { bottom: { style: BorderStyle.SINGLE, size: 8, color: "1F3A5F" } },
    spacing: { after: 80 },
    children: [
      new TextRun({ text: title, font: "Arial", size: 16, color: "1F3A5F", bold: true }),
      new TextRun({ text: "   ·   Blackwood Archives training", font: "Arial", size: 16, color: "6B7280" }),
    ],
  })] });
}
function footer() {
  return new Footer({ children: [new Paragraph({
    alignment: AlignmentType.RIGHT,
    border: { top: { style: BorderStyle.SINGLE, size: 6, color: "D1D5DB" } },
    children: [
      new TextRun({ text: "стр. ", font: "Arial", size: 16, color: "6B7280" }),
      new TextRun({ children: [PageNumber.CURRENT], font: "Arial", size: 16, color: "6B7280" }),
    ],
  })] });
}

function section(title, children) {
  return {
    properties: { page: { size: A4, margin: { top: 1080, right: 1080, bottom: 1080, left: 1080 } } },
    headers: { default: header(title) },
    footers: { default: footer() },
    children,
  };
}

const student = new Document({
  styles, numbering,
  sections: [section("VaultGate 1.3  ·  задания", [
    h1("Лабораторная работа: VaultGate 1.3"),
    p("Практический реверс небольшого Windows GUI-приложения. Кейген писать не нужно: достаточно понять логику, восстановить данные или аккуратно пропатчить проверку."),
    table(
      ["Параметр", "Значение"],
      [
        ["Файл", "VaultGate.exe  (32-bit PE, Win32 API)"],
        ["Формат флагов", "TRAIN{...}"],
        ["Основных флагов", "4 + 1 бонус"],
        ["Инструменты", "strings, DIE/CFF, Ghidra или IDA, x32dbg, Resource Hacker"],
      ],
      [2800, 6946]
    ),
    h2("Правила"),
    num("Работаете только с выданным бинарём и его копиями под патч."),
    num("Цель — понять логику и достать флаги, а не подобрать пароль перебором вслепую."),
    num("Патч легитимен, если вы понимаете, что именно меняете."),
    num("В файле есть ложные строки. Если флаг выглядит слишком просто — это приманка."),
    num("Сдавать: список флагов и по 5–10 строк, как каждый получен."),
    h2("Что на экране"),
    p("Окно «VaultGate 1.3 — Blackwood Archives»: поле Gate code + Unlock, поле Seal no. + Verify seal, неактивная кнопка Open archive, меню File / Help. Секреты независимы и решаются в любом порядке."),
    h2("Задание 1. Разведка бинаря"),
    p("Снимите паспорт файла: разрядность, компилятор, секции, ресурсы, строки. Найдите скрытый флаг, которого нет в открытом виде в strings. Рядом с ним лежит короткий ключ. Тот же флаг можно получить вторым путём, не декодируя массив руками."),
    p("Сдать: флаг №1 и где он жил.", { italics: true }),
    note("Подсказки. 1) Version Info и таблица строк — обязательно, но не останавливайтесь на первом FLAG{...}.  2) Массив ~25 байт и одиночная константа-ключ рядом.  3) Функция декодирования почти не вызывается — посмотрите аргументы WinMain."),
    h2("Задание 2. Gate code"),
    p("Unlock пропускает один восьмисимвольный код. Это не strcmp с паролем в открытом виде. Нужно восстановить преобразование и либо вычислить код, либо обойти проверку так, чтобы расшифровался настоящий флаг."),
    p("Слепой патч «всегда успех» может включить кнопку, но не обязан показать корректный флаг: полезная нагрузка завязана на введённую строку."),
    p("Сдать: валидный gate code, флаг №2 и краткое описание преобразования.", { italics: true }),
    note("Подсказки. 1) Длина проверяется отдельно.  2) Цепочка XOR с бегущим аккумулятором и константным стартом.  3) Строка letmein! в бинаре специально не работает."),
    h2("Задание 3. Печать документа"),
    p("Seal no. принимает четырёхзначное число. Проверка — набор арифметических условий, а не сравнение с константой в лоб. Само число уже мелькает в интерфейсе и в метаданных файла. По отдельности условия пропускают несколько кандидатов — нужны все."),
    p("После верного seal и успешного Unlock кнопка Open archive отдаёт флаг №3."),
    p("Сдать: seal number и флаг №3.", { italics: true }),
    note("Подсказки. 1) About и VERSIONINFO стоит прочитать целиком.  2) Три условия: сумма цифр, остаток, XOR с константой.  3) Build number и seal — одно и то же."),
    h2("Задание 4. То, чего нет на кнопках"),
    p("Не вся логика сидит на Unlock / Verify. В окне есть элемент, который выглядит как декоративный заголовок, но ведёт себя иначе, чем обычная подпись."),
    p("Сдать: флаг №4 и какой UI-элемент его открывает.", { italics: true }),
    note("Подсказки. 1) В стилях контрола есть SS_NOTIFY.  2) Счётчик кликов.  3) Заголовок красным по центру."),
    h2("Задание 5. Бонус — дешёвый антиотладчик"),
    p("В программе есть вызов IsDebuggerPresent. Он влияет как минимум на два места: на проверку gate code и на текст About. Достаньте бонусный флаг: честно отлаживаясь, спрятав факт отладки или пропатчив проверку."),
    p("Сдать: флаг №5 и какой путь выбрали.", { italics: true }),
    note("Подсказки. 1) Help → About под отладчиком выглядит иначе.  2) Если Unlock ломается только под x32dbg — виновато отравление первого байта, не алгоритм.  3) Help → Diagnostics капризный, но не бесполезный."),
    h2("Критерии"),
    table(
      ["Уровень", "Что получилось"],
      [
        ["Зачёт", "Флаги 1–3 и понятное описание"],
        ["Хорошо", "Все основные флаги 1–4"],
        ["Отлично", "Все пять, антиотладчик обойден осознанно"],
      ],
      [2400, 7346]
    ),
    p("Патч без понимания («NOP на первый попавшийся jz») слабее восстановленного алгоритма, даже если флаг тот же.", { italics: true }),
  ])],
});

const trainer = new Document({
  styles, numbering,
  sections: [section("VaultGate 1.3  ·  гайд тренера", [
    h1("Гайд для тренера"),
    p("Раздайте участникам только VaultGate.exe и файл с заданиями. Исходники vaultgate.c / vaultgate.rc и этот гайд остаются у вас."),
    code("cd vaultgate && sh build.sh"),
    p("Бинарник: 32-bit PE GUI, без символов (-s), без оптимизаций (-O0). В дизассемблере код линейный — так и задумано."),
    h2("Карта секретов"),
    table(
      ["#", "Флаг", "Как получают"],
      [
        ["1", "TRAIN{static_is_not_dead}", "XOR-блоб ключом 0x3B  или  --archivist"],
        ["2", "TRAIN{chained_xor_walk}", "пароль W0lf-Eye → Unlock"],
        ["3", "TRAIN{about_is_a_hint}", "seal 1847 + Unlock + Open archive"],
        ["4", "TRAIN{five_clicks_deep}", "5 кликов по красному заголовку"],
        ["5", "TRAIN{dont_trust_peb}", "About под отладчиком / патч IsDebuggerPresent"],
      ],
      [700, 4200, 4846]
    ),
    p("Gate code: W0lf-Eye.   Seal: 1847.", { bold: true }),
    p("Приманки: FLAG{not_this_one}, admin:admin, serial:0000-0000-0000, letmein!"),
    h2("Архитектура"),
    p("Одно окно, чистый Win32, класс VaultGateWnd. Состояние: g_unlocked, g_sealOk, g_clicks. Кнопка Open archive создаётся с WS_DISABLED. Имена функций сожжены -s, ориентир — строки и импорты."),
    table(
      ["Логика", "Зацепка в бинаре"],
      [
        ["vg_auth_gate", "letmein!, константа 0x5A, массив 8 байт"],
        ["vg_decrypt_flag2", "только после успеха auth, цикл i*7+3"],
        ["vg_seal_probe", "atoi, сравнения с 20, 73/22, 0x7A1/0x96"],
        ["vg_reveal_static", "Archivist override, блоб 25 байт, ключ 0x3B"],
        ["Баннер", "STN_CLICKED, счётчик до 5"],
        ["Антиотладка", "два осмысленных вызова IsDebuggerPresent"],
      ],
      [2800, 6946]
    ),
    h2("Задание 1 — решение"),
    h3("Путь A. Блоб"),
    p("strings не содержит настоящих TRAIN{...}. В коде массив:"),
    code("6F 69 7A 72 75 40 48 4F 5A 4F 52 58 64 52 48 64 55 54 4F 64 5F 5E 5A 5F 46"),
    p("Ключ 0x3B лежит рядом. XOR каждого байта даёт TRAIN{static_is_not_dead}."),
    h3("Путь B. Командная строка"),
    p("WinMain ищет подстроку --archivist в lpCmdLine и вызывает декодер. Запуск VaultGate.exe --archivist сразу показывает тот же флаг. Хороший повод напомнить смотреть аргументы входа."),
    h2("Задание 2 — решение"),
    p("Алгоритм vg_auth_gate:"),
    code("если pass == \"letmein!\" → -1   (revoked, не успех)"),
    code("если длина != 8 → 0"),
    code("acc = 0x5A;  out[i] = pass[i] XOR acc;  acc += out[i] + i"),
    code("если IsDebuggerPresent(): out[0] ^= 0xFF"),
    code("сравнить out с 0D 57 D3 F2 A4 74 D3 E6"),
    p("Обратный ход однозначен, потому что аккумулятор бежит в ту же сторону:"),
    code("tgt = [0x0D,0x57,0xD3,0xF2,0xA4,0x74,0xD3,0xE6]; acc=0x5A"),
    code("pass[i] = tgt[i] XOR acc;  acc = (acc + tgt[i] + i) & 0xFF"),
    code("результат: W0lf-Eye"),
    p("Флаг №2 расшифровывается из 23-байтного блоба через"),
    code("out[i] = enc2[i] XOR pass[i%8] XOR ((i*7+3)&0xFF)"),
    p("Поэтому патч «всегда return 1» при пустом поле даёт кашу. Нужен либо пароль, либо ручной декод с подставленным W0lf-Eye."),
    note("Грабли: под x32dbg правильный пароль внезапно не проходит — отравление out[0]. Лечится ScyllaHide / патчем PEB / патчем конкретного вызова. Включение Open archive через WS_DISABLED не закрывает задание 2."),
    h2("Задание 3 — решение"),
    p("Три условия seal: сумма цифр == 20, n % 73 == 22, n XOR 0x7A1 == 0x96. Первые два оставляют восемь кандидатов (1847, 3818, 4475, 6446, 7760, 8417, 9074, 9731), третье — только 1847."),
    p("Число и так светится: About «Build 1847», стартовый статус, VERSIONINFO 1.3.0.1847. Флаг №3 — XOR 0x55 от TRAIN{about_is_a_hint}, показывается в Open archive, когда оба глобальных флага равны 1. На пароль он не завязан, поэтому патч двух проверок в Open archive тоже работает."),
    h2("Задание 4 — решение"),
    p("Красный STATIC «BLACKWOOD DOCUMENT VAULT» создан со стилем SS_CENTER | SS_NOTIFY. WM_COMMAND ловит STN_CLICKED, копит g_clicks и на пятёрке декодирует блоб ключом 0x19 → TRAIN{five_clicks_deep}."),
    p("Мягкая подсказка в UI: «Some fixtures in this room give way if pressed long enough.» После 1–4 кликов статус пишет The vault notices (k/5)."),
    h2("Задание 5 — решение"),
    p("Два вызова IsDebuggerPresent: в auth портит out[0], в About дописывает Debug watermark с флагом TRAIN{dont_trust_peb}. Пути: открыть About под отладчиком; пропатчить только about-вызов в return 1; XOR блоба kFlag5Enc ключом 0x2E."),
    p("Help → Diagnostics без Shift отказывает. С зажатым Shift даёт короткие подсказки про PEB, блоб и три условия seal — клапан для отстающих."),
    h2("Как вести занятие"),
    table(
      ["Минуты", "Что происходит"],
      [
        ["0–15", "Раздать exe, свободная разведка, общий разбор PE и ресурсов"],
        ["15–40", "Задание 1; сверка, кто повёлся на FLAG{not_this_one}"],
        ["40–90", "Задание 2. Если упёрлись — показать только форму цикла XOR"],
        ["90–110", "Задание 3, обычно быстро после About"],
        ["110–130", "Задание 4 и бонус"],
        ["130–150", "Разбор «как надо было», патч vs понимание"],
      ],
      [1800, 7946]
    ),
    h2("Что проговорить вслух"),
    bullet("strings необходим, но не достаточен."),
    bullet("Сравнение после преобразования ≠ хранение пароля в открытом виде."),
    bullet("Глобальный unlocked почти всегда ставится патчем; полезная нагрузка может быть отдельным слоем."),
    bullet("IsDebuggerPresent читает байт PEB и обходится за секунду — отсюда имя бонусного флага."),
    bullet("GUI-реверс = код + стили контролов + ресурсы + командная строка."),
    h2("Проверка работ"),
    bullet("FLAG{not_this_one} не засчитывать, спросить почему решили, что это он."),
    bullet("Одно число 1847 без флага №3 — половина задания 3."),
    bullet("Включённая Open archive без флага №2 — задание 2 не закрыто."),
    bullet("TRAIN{dont_trust_peb} как «флаг разведки» засчитать только как бонус."),
    h2("Как крутить сложность на следующий поток"),
    p("Упростить: убрать отравление out[0]; сделать seal прямым cmp n, 1847; вызвать декодер статики из About."),
    p("Усложнить: убрать подсказку про fixtures и статус k/5; заменить IsDebuggerPresent на NtGlobalFlag / HeapFlags; повесить CRC участка .text перед Open archive, чтобы наивный патч Unlock ломал флаг №3."),
  ])],
});

async function main() {
  const a = await Packer.toBuffer(student);
  const b = await Packer.toBuffer(trainer);
  fs.writeFileSync("/home/workdir/artifacts/docs/VaultGate_zadaniya.docx", a);
  fs.writeFileSync("/home/workdir/artifacts/docs/VaultGate_gid_trenera.docx", b);
  console.log("wrote docx", a.length, b.length);
}
main().catch((e) => { console.error(e); process.exit(1); });
