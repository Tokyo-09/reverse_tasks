#!/bin/sh
set -e
i686-w64-mingw32-windres vaultgate.rc -O coff -o vaultgate.res
i686-w64-mingw32-gcc -O0 -s -mwindows -Wall vaultgate.c vaultgate.res -o VaultGate.exe
echo "Built $(ls -l VaultGate.exe)"
