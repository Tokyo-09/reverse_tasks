#define WIN32_LEAN_AND_MEAN
#define _WIN32_WINNT 0x0501
#include <windows.h>
#include <stdlib.h>
#include <string.h>

#define ID_BANNER      1001
#define ID_LBL_CODE    1002
#define ID_EDIT_CODE   1003
#define ID_BTN_UNLOCK  1004
#define ID_LBL_SEAL    1005
#define ID_EDIT_SEAL   1006
#define ID_BTN_SEAL    1007
#define ID_BTN_ARCHIVE 1008
#define ID_STATUS      1009

#define IDM_EXIT       2001
#define IDM_ABOUT      2002
#define IDM_DIAG       2003

#define IDD_ABOUT      3001
#define IDC_ABOUT_TXT  3002

static HWND g_editCode;
static HWND g_editSeal;
static HWND g_btnArchive;
static HWND g_status;
static HWND g_banner;
static HINSTANCE g_inst;
static int g_unlocked = 0;
static int g_clicks = 0;
static int g_sealOk = 0;

/* Decoys — leave them, they waste time on purpose. */
static const char *kDecoy1 = "FLAG{not_this_one}";
static const char *kDecoy2 = "admin:admin";
static const char *kDecoy3 = "serial:0000-0000-0000";
static const char *kDecoy4 = "TODO: remove test backdoor before release";

/* Task 1 blob. Key is 0x3B. Plaintext: TRAIN{static_is_not_dead} */
static const unsigned char kStaticBlob[] = {
    0x6F, 0x69, 0x7A, 0x72, 0x75, 0x40, 0x48, 0x4F, 0x5A, 0x4F,
    0x52, 0x58, 0x64, 0x52, 0x48, 0x64, 0x55, 0x54, 0x4F, 0x64,
    0x5F, 0x5E, 0x5A, 0x5F, 0x46
};
static const unsigned char kStaticKey = 0x3B;

/* Chained-XOR target for passphrase "W0lf-Eye", acc starts at 0x5A. */
static const unsigned char kGateTarget[] = {
    0x0D, 0x57, 0xD3, 0xF2, 0xA4, 0x74, 0xD3, 0xE6
};

/* Flag 2 encrypted with passphrase + stream. */
static const unsigned char kFlag2Enc[] = {
    0x00, 0x68, 0x3C, 0x37, 0x7C, 0x18, 0x37, 0x39, 0x0D, 0x1B,
    0x4B, 0x53, 0x1E, 0x44, 0x64, 0x66, 0x56, 0x15, 0x9A, 0x8F,
    0xCE, 0xB8, 0x99
};

/* Flag 3: TRAIN{about_is_a_hint} xor 0x55 */
static const unsigned char kFlag3Enc[] = {
    0x01, 0x07, 0x14, 0x1C, 0x1B, 0x2E, 0x34, 0x37, 0x3A, 0x20,
    0x21, 0x0C, 0x3C, 0x26, 0x0C, 0x34, 0x0C, 0x3D, 0x3C, 0x3B,
    0x21, 0x28
};

/* Flag 4: TRAIN{five_clicks_deep} xor 0x19 */
static const unsigned char kFlag4Enc[] = {
    0x4D, 0x4B, 0x58, 0x50, 0x57, 0x62, 0x7F, 0x70, 0x6F, 0x7C,
    0x46, 0x7A, 0x75, 0x70, 0x7A, 0x72, 0x6A, 0x46, 0x7D, 0x7C,
    0x7C, 0x69, 0x64
};

static void xor_copy(char *dst, const unsigned char *src, int n, unsigned char key)
{
    int i;
    for (i = 0; i < n; i++)
        dst[i] = (char)(src[i] ^ key);
    dst[n] = 0;
}

static void set_status(const char *s)
{
    SetWindowTextA(g_status, s);
}

/* Dead / cmdline-only decoder for Task 1. */
static void vg_reveal_static(HWND owner)
{
    char buf[40];
    xor_copy(buf, kStaticBlob, (int)sizeof(kStaticBlob), kStaticKey);
    MessageBoxA(owner, buf, "Archivist override", MB_OK | MB_ICONINFORMATION);
}

static int vg_auth_gate(const char *p)
{
    unsigned char acc = 0x5A;
    unsigned char out[8];
    int i;
    size_t n;

    /* Red herring path — always fails. */
    if (lstrcmpA(p, "letmein!") == 0)
        return -1;

    n = strlen(p);
    if (n != 8)
        return 0;

    for (i = 0; i < 8; i++) {
        out[i] = (unsigned char)p[i] ^ acc;
        acc = (unsigned char)(acc + out[i] + i);
    }

    /* If a debugger is attached the comparison is poisoned.
       Students either hide the debugger or patch this branch. */
    if (IsDebuggerPresent())
        out[0] ^= 0xFF;

    for (i = 0; i < 8; i++) {
        if (out[i] != kGateTarget[i])
            return 0;
    }
    return 1;
}

static void vg_decrypt_flag2(const char *pass, char *out)
{
    int i;
    int n = (int)sizeof(kFlag2Enc);
    int klen = (int)strlen(pass);
    for (i = 0; i < n; i++) {
        unsigned char mix = (unsigned char)((i * 7 + 3) & 0xFF);
        out[i] = (char)(kFlag2Enc[i] ^ (unsigned char)pass[i % klen] ^ mix);
    }
    out[n] = 0;
}

static int vg_seal_probe(int n)
{
    int s = 0;
    int t = n;
    if (n < 1000 || n > 9999)
        return 0;
    while (t) {
        s += t % 10;
        t /= 10;
    }
    /* 1847: digit-sum 20, n % 73 == 22, n ^ 0x7A1 == 0x96 */
    if (s != 20)
        return 0;
    if ((n % 73) != 22)
        return 0;
    if ((n ^ 0x7A1) != 0x96)
        return 0;
    return 1;
}

static void vg_open_archive(HWND hwnd)
{
    char msg[256];
    char f3[40];
    if (!g_unlocked) {
        set_status("Archive lock is intact. Authenticate first.");
        MessageBoxA(hwnd,
                    "The archive remains sealed.\r\nAuthenticate with a valid gate code.",
                    "VaultGate", MB_OK | MB_ICONWARNING);
        return;
    }
    if (!g_sealOk) {
        set_status("Seal number has not been verified.");
        MessageBoxA(hwnd,
                    "Gate is open, but the document seal is still intact.\r\nVerify the seal number first.",
                    "VaultGate", MB_OK | MB_ICONWARNING);
        return;
    }
    xor_copy(f3, kFlag3Enc, (int)sizeof(kFlag3Enc), 0x55);
    wsprintfA(msg,
              "Blackwood Archives — dossier 1847 released.\r\n\r\nClearance token:\r\n%s",
              f3);
    MessageBoxA(hwnd, msg, "Archive open", MB_OK | MB_ICONINFORMATION);
    set_status("Archive opened.");
}

static void do_unlock(HWND hwnd)
{
    char code[64];
    char flag[40];
    int rc;

    GetWindowTextA(g_editCode, code, sizeof(code));
    rc = vg_auth_gate(code);

    if (rc == -1) {
        set_status("Legacy credentials revoked in build 1847.");
        MessageBoxA(hwnd, "Those credentials were retired years ago.",
                    "VaultGate", MB_OK | MB_ICONWARNING);
        return;
    }
    if (rc != 1) {
        set_status("Gate rejected the code.");
        MessageBoxA(hwnd, "Access denied.", "VaultGate", MB_OK | MB_ICONERROR);
        return;
    }

    g_unlocked = 1;
    EnableWindow(g_btnArchive, TRUE);
    vg_decrypt_flag2(code, flag);
    set_status(flag);
    MessageBoxA(hwnd, flag, "Access granted", MB_OK | MB_ICONINFORMATION);
}

static void do_seal(HWND hwnd)
{
    char buf[32];
    int n;

    GetWindowTextA(g_editSeal, buf, sizeof(buf));
    n = atoi(buf);
    if (!vg_seal_probe(n)) {
        g_sealOk = 0;
        set_status("Seal mismatch.");
        MessageBoxA(hwnd, "The seal number does not match the dossier.",
                    "VaultGate", MB_OK | MB_ICONERROR);
        return;
    }
    g_sealOk = 1;
    set_status("Seal accepted. Archive can be opened after authentication.");
    MessageBoxA(hwnd,
                "Seal accepted.\r\nHint: the build number was never a secret.",
                "VaultGate", MB_OK | MB_ICONINFORMATION);
}

/* Bonus flag: TRAIN{dont_trust_peb} xor 0x2E */
static const unsigned char kFlag5Enc[] = {
    0x7A, 0x7C, 0x6F, 0x67, 0x60, 0x55, 0x4A, 0x41, 0x40, 0x5A,
    0x71, 0x5A, 0x5C, 0x5F, 0x5D, 0x5A, 0x71, 0x5E, 0x4B, 0x4C,
    0x53
};

static void do_about(HWND hwnd)
{
    char text[512];
    char extra[80];
    char f5[32];

    extra[0] = 0;
    if (IsDebuggerPresent()) {
        xor_copy(f5, kFlag5Enc, (int)sizeof(kFlag5Enc), 0x2E);
        wsprintfA(extra, "\r\n\r\nDebug watermark: %s", f5);
    }

    wsprintfA(text,
              "VaultGate  1.3\r\n"
              "Build 1847\r\n"
              "Blackwood Archives — internal use only\r\n\r\n"
              "Document vault client.\r\n"
              "Unauthorized reverse engineering is\r\n"
              "strictly encouraged in the training lab.%s",
              extra);
    MessageBoxA(hwnd, text, "About VaultGate", MB_OK | MB_ICONINFORMATION);
}

static void do_diag(HWND hwnd)
{
    /* Menu item is enabled only while SHIFT is held on Help menu...
       actually we check SHIFT here. */
    if (!(GetAsyncKeyState(VK_SHIFT) & 0x8000)) {
        MessageBoxA(hwnd,
                    "Diagnostics are restricted.\r\nHold SHIFT when opening this item.",
                    "Diagnostics", MB_OK | MB_ICONWARNING);
        return;
    }
    MessageBoxA(hwnd,
                "diag.ok\r\npeb.BeingDebugged is the cheap probe.\r\n"
                "static blob key lives next to the ciphertext.\r\n"
                "seal constraints: sum, mod, xor.",
                "Diagnostics", MB_OK | MB_ICONINFORMATION);
}

static LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch (msg) {
    case WM_CREATE: {
        HMENU menubar = CreateMenu();
        HMENU mFile = CreateMenu();
        HMENU mHelp = CreateMenu();
        AppendMenuA(mFile, MF_STRING, IDM_EXIT, "E&xit");
        AppendMenuA(mHelp, MF_STRING, IDM_DIAG, "&Diagnostics");
        AppendMenuA(mHelp, MF_STRING, IDM_ABOUT, "&About");
        AppendMenuA(menubar, MF_POPUP, (UINT_PTR)mFile, "&File");
        AppendMenuA(menubar, MF_POPUP, (UINT_PTR)mHelp, "&Help");
        SetMenu(hwnd, menubar);

        CreateWindowA("STATIC",
                      "BLACKWOOD  DOCUMENT  VAULT",
                      WS_CHILD | WS_VISIBLE | SS_CENTER | SS_NOTIFY,
                      20, 16, 440, 22, hwnd, (HMENU)ID_BANNER, g_inst, NULL);

        CreateWindowA("STATIC",
                      "Some fixtures in this room give way if pressed long enough.",
                      WS_CHILD | WS_VISIBLE | SS_LEFT,
                      20, 42, 440, 18, hwnd, NULL, g_inst, NULL);

        CreateWindowA("STATIC", "Gate code:",
                      WS_CHILD | WS_VISIBLE,
                      20, 78, 80, 18, hwnd, NULL, g_inst, NULL);
        g_editCode = CreateWindowA("EDIT", "",
                      WS_CHILD | WS_VISIBLE | WS_BORDER | ES_AUTOHSCROLL,
                      110, 74, 220, 24, hwnd, (HMENU)ID_EDIT_CODE, g_inst, NULL);
        CreateWindowA("BUTTON", "Unlock",
                      WS_CHILD | WS_VISIBLE | BS_DEFPUSHBUTTON,
                      344, 72, 116, 28, hwnd, (HMENU)ID_BTN_UNLOCK, g_inst, NULL);

        CreateWindowA("STATIC", "Seal no.:",
                      WS_CHILD | WS_VISIBLE,
                      20, 118, 80, 18, hwnd, NULL, g_inst, NULL);
        g_editSeal = CreateWindowA("EDIT", "",
                      WS_CHILD | WS_VISIBLE | WS_BORDER | ES_NUMBER | ES_AUTOHSCROLL,
                      110, 114, 220, 24, hwnd, (HMENU)ID_EDIT_SEAL, g_inst, NULL);
        CreateWindowA("BUTTON", "Verify seal",
                      WS_CHILD | WS_VISIBLE,
                      344, 112, 116, 28, hwnd, (HMENU)ID_BTN_SEAL, g_inst, NULL);

        g_btnArchive = CreateWindowA("BUTTON", "Open archive",
                      WS_CHILD | WS_VISIBLE | WS_DISABLED,
                      110, 156, 220, 32, hwnd, (HMENU)ID_BTN_ARCHIVE, g_inst, NULL);

        g_status = CreateWindowA("STATIC",
                      "Awaiting credentials. Build 1847.",
                      WS_CHILD | WS_VISIBLE | SS_LEFT,
                      20, 210, 440, 40, hwnd, (HMENU)ID_STATUS, g_inst, NULL);

        CreateWindowA("STATIC",
                      "Blackwood Archives  |  VaultGate 1.3  |  classified",
                      WS_CHILD | WS_VISIBLE | SS_CENTER,
                      20, 258, 440, 18, hwnd, NULL, g_inst, NULL);
        break;
    }
    case WM_COMMAND: {
        int id = LOWORD(wParam);
        int code = HIWORD(wParam);
        if (id == ID_BANNER && code == STN_CLICKED) {
            char f4[40];
            g_clicks++;
            if (g_clicks < 5) {
                char tmp[64];
                wsprintfA(tmp, "The vault notices (%d/5).", g_clicks);
                set_status(tmp);
            } else if (g_clicks == 5) {
                xor_copy(f4, kFlag4Enc, (int)sizeof(kFlag4Enc), 0x19);
                set_status(f4);
                MessageBoxA(hwnd, f4, "A loose tile", MB_OK | MB_ICONINFORMATION);
            }
            return 0;
        }
        switch (id) {
        case ID_BTN_UNLOCK:
            do_unlock(hwnd);
            break;
        case ID_BTN_SEAL:
            do_seal(hwnd);
            break;
        case ID_BTN_ARCHIVE:
            vg_open_archive(hwnd);
            break;
        case IDM_EXIT:
            PostMessage(hwnd, WM_CLOSE, 0, 0);
            break;
        case IDM_ABOUT:
            do_about(hwnd);
            break;
        case IDM_DIAG:
            do_diag(hwnd);
            break;
        }
        break;
    }
    case WM_CTLCOLORSTATIC: {
        HDC hdc = (HDC)wParam;
        HWND ctl = (HWND)lParam;
        if (ctl == g_banner) {
            SetTextColor(hdc, RGB(180, 30, 30));
            SetBkMode(hdc, TRANSPARENT);
            return (LRESULT)GetStockObject(HOLLOW_BRUSH);
        }
        break;
    }
    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProcA(hwnd, msg, wParam, lParam);
}

int WINAPI WinMain(HINSTANCE inst, HINSTANCE prev, LPSTR cmd, int show)
{
    WNDCLASSA wc;
    HWND hwnd;
    MSG msg;
    HFONT font;

    (void)prev;
    g_inst = inst;

    /* Unused decoys so the compiler keeps the strings. */
    if (kDecoy1[0] == '!' && kDecoy2[0] == '!' && kDecoy3[0] == '!' && kDecoy4[0] == '!')
        return 0;

    if (cmd && strstr(cmd, "--archivist")) {
        vg_reveal_static(NULL);
    }

    memset(&wc, 0, sizeof(wc));
    wc.lpfnWndProc   = WndProc;
    wc.hInstance     = inst;
    wc.lpszClassName = "VaultGateWnd";
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    wc.hCursor       = LoadCursor(NULL, IDC_ARROW);
    wc.hIcon         = LoadIcon(NULL, IDI_APPLICATION);
    if (!RegisterClassA(&wc))
        return 1;

    hwnd = CreateWindowA("VaultGateWnd",
                         "VaultGate 1.3 — Blackwood Archives",
                         WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX,
                         CW_USEDEFAULT, CW_USEDEFAULT, 500, 340,
                         NULL, NULL, inst, NULL);
    if (!hwnd)
        return 2;

    font = CreateFontA(16, 0, 0, 0, FW_NORMAL, 0, 0, 0,
                       DEFAULT_CHARSET, 0, 0, 0, 0, "Segoe UI");
    if (font)
        SendMessage(hwnd, WM_SETFONT, (WPARAM)font, TRUE);

    ShowWindow(hwnd, show);
    UpdateWindow(hwnd);

    while (GetMessage(&msg, NULL, 0, 0) > 0) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
    return (int)msg.wParam;
}
