# NexusForge 2.4.1 «Obsidian»

Локальная платформа рабочего пространства: заметки, задачи, хранилище, executive-отчёты, AI-дайджест, журнал аудита и webhooks.

Поставляется как **Community Edition**. Аналитический и интеграционный контур закрыт коммерческой лицензией Enterprise. Файл лицензии — `var/license.nfx` в конверте `BEGIN NEXUSFORGE LICENSE`.

Это учебный продукт для тренинга по реверс-инжинирингу Python-приложений. Он выглядит и устроен как небольшой внутренний SaaS, но все проверки лицензии выполняются локально и намеренно доступны для исследования.

## Быстрый старт

```bash
cd nexusforge
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export PYTHONPATH=.
python3 -m nexusforge info
python3 -m nexusforge serve --host 127.0.0.1 --port 8040
```

Откройте http://127.0.0.1:8040

## Что есть в Community

- Дашборд
- Заметки и задачи
- Лимит 25 заметок / 40 задач
- Страница активации лицензии
- API `/api/health` и `/api/docs`

## Что закрыто Enterprise

- Secure Vault
- Executive Reports
- AI Digest
- Audit Trail
- Webhooks
- Снятие лимитов

Заблокированные разделы отвечают редиректом на `/upgrade` или HTTP 402 на API.

## Лицензии

Примеры лежат в `samples/`:

- `community.nfx` — валидная community-лицензия
- `enterprise.forged.nfx` — выглядит как Enterprise, но печать (`seal`) поддельная
- `enterprise.valid.nfx` — **не выдаётся студентам по умолчанию**; генерируется инструктором

Активация:

```bash
python3 -m nexusforge activate samples/community.nfx
```

Выпуск подписанной лицензии (вендорский CLI, есть в дереве специально):

```bash
python3 -m nexusforge mint --licensee "ACME Lab" -o samples/enterprise.valid.nfx
```

## Структура

```
nexusforge/
  licensing/     политика лицензий, конверт, печать, entitlements, gates
  services/      заметки, задачи, «интеллект», seed
  web/           Jinja-шаблоны и статика
  app.py         FastAPI
  cli.py         info / serve / activate / mint
```

Данные и установленная лицензия пишутся в `var/`.
