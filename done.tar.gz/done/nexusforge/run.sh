#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONPATH="."
exec python3 -m nexusforge serve --host 127.0.0.1 --port 8040 "$@"
