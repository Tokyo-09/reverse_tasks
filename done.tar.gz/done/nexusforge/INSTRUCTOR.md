# Инструктор: карта проверок и сценарий

Не раздавайте этот файл студентам в первом заходе.

## Задумка

Приложение достаточно большое, чтобы «искать глазами», но не является обфусцированным малварь-паком. Все ветки лицензии локальные. Есть три легитимных учебных пути и несколько ложных следов.

## Где принимается решение

| Слой | Файл | Функция | Что делает |
|---|---|---|---|
| Конверт файла | `nexusforge/licensing/codec.py` | `decode_document` | base64+JSON внутри PEM-подобного блока |
| Печать | `nexusforge/licensing/seal.py` | `materialize_verifier`, `compute_seal`, `seals_match` | HMAC-SHA256, ключ собирается из кусков |
| Политика | `nexusforge/licensing/engine.py` | `evaluate_document` | даты, tier, вызов `seals_match` |
| Сборка прав | `nexusforge/licensing/entitlements.py` | `_from_license` | если `doc.valid` и enterprise-tier / `enterprise.suite` — выдаёт полный набор |
| Гейты | `nexusforge/licensing/gates.py` | `feature_allowed`, `require_feature`, `enterprise_route` | 402 и `FeatureLocked` |
| Сервисы | `nexusforge/services/intel.py`, `workspace.py` | `require_feature` / прямые `allows` | повторная проверка, не только UI |
| Кэш | `entitlements.py` | `current_entitlements` | `lru_cache`; после патча на лету нужен рестарт или `refresh_entitlements` |

Community fallback в `community_fallback()` специально ставит `valid=True` **без** печати. Это не дыра для Enterprise: `_from_license` смотрит на tier/sku/features.

## Рекомендуемый порядок занятия (90–120 мин)

1. 10 мин: запуск, клики по UI, фиксация 402.
2. 15 мин: разведка дерева, `grep -R enterprise`, `grep -R 402`, чтение `/upgrade`.
3. 20 мин: попытка скормить `samples/enterprise.forged.nfx` — должна отвалиться с `Integrity seal rejected`.
4. 25 мин: патч. Самые короткие успешные варианты ниже.
5. 15 мин: разбор, почему патча только шаблона меню недостаточно.
6. 15 мин: продвинутый путь — написать генератор лицензии.

## Короткие патчи, которые должны срабатывать

### A. Грубый гейт

В `gates.py`:

```python
def feature_allowed(feature: str) -> bool:
    return True
```

Этого хватает для маршрутов и части сервисов, которые зовут `require_feature` / `feature_allowed`. Лимиты заметок живут в `workspace.py` через `ent.note_limit` — участник увидит, что «безлимит» мог не открыться.

### B. Политика entitlements (чистый путь)

В `_from_license` принудительно `enterprise_granted = True`.

Открывает и фичи, и лимиты.

### C. Печать

В `seals_match` всегда `return True`, плюс подложить forged-файл с `tier=enterprise`. Без файла/без tier одного только `return True` мало: community fallback останется community.

### D. Честный ключ

Собрать ключ так же, как `materialize_verifier()`, подписать payload, положить в `var/license.nfx`. Либо воспользоваться скрытым на виду CLI:

```bash
python3 -m nexusforge mint --licensee "Student" -o var/license.nfx
```

Для группы можно заранее вырезать команду `mint` из раздаточного архива и оставить её только в эталоне.

## Ложные следы, которые полезны

- `__edition__ = "community"` в `__init__.py` ни на что не влияет.
- Поле `seal: community-unsigned` у fallback.
- HTTP 402 и текст «payment_required» — люди полезют в платёжный контур, которого нет.
- `APP_SALT` выглядит как единственный секрет, но ключ — SHA256 от склейки четырёх частей.

## Оценка

- Зачёт: любой путь, после которого `/api/report` отдаёт JSON, а не 402, и в UI открыт хотя бы Reports.
- Хорошо: объяснили разницу UI-гейта и сервисного `require_feature`.
- Отлично: выпустили собственный валидный `.nfx` без патча логики.

## Усложнения на второй день

- Собрать PyInstaller one-file и искать те же функции в дизасме / `pyinstxtractor`.
- Вынести `seal.py` в `.pyc` без исходника.
- Добавить вторую проверку: хеш `engine.py` при старте.
- Онлайн-активация-заглушка, которая «не достучалась до licensing.nexusforge.example».
