"""Wire format for .nfx license documents.

The on-disk format is intentionally a bit ceremonial so that the file
looks like a commercial license blob rather than a plain JSON file.
"""

from __future__ import annotations

import base64
import json
from typing import Any

HEADER = "-----BEGIN NEXUSFORGE LICENSE-----"
FOOTER = "-----END NEXUSFORGE LICENSE-----"


class LicenseCodecError(ValueError):
    pass


def encode_document(payload: dict[str, Any]) -> str:
    raw = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode("utf-8")
    b64 = base64.b64encode(raw).decode("ascii")
    wrapped = "\n".join(b64[i : i + 64] for i in range(0, len(b64), 64))
    return f"{HEADER}\n{wrapped}\n{FOOTER}\n"


def decode_document(text: str) -> dict[str, Any]:
    text = text.replace("\r\n", "\n").strip()
    if HEADER not in text or FOOTER not in text:
        raise LicenseCodecError("Malformed license envelope")
    body = text.split(HEADER, 1)[1].split(FOOTER, 1)[0]
    compact = "".join(body.split())
    try:
        raw = base64.b64decode(compact.encode("ascii"), validate=True)
        data = json.loads(raw.decode("utf-8"))
    except Exception as exc:  # noqa: BLE001
        raise LicenseCodecError("License payload is not valid") from exc
    if not isinstance(data, dict):
        raise LicenseCodecError("License payload must be an object")
    return data
