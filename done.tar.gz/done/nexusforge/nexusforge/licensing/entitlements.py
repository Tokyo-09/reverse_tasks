from __future__ import annotations

from dataclasses import dataclass, field
from functools import lru_cache

from nexusforge.licensing.engine import LicenseDocument, load_license


ENTERPRISE_FEATURES = (
    "vault",
    "executive_reports",
    "audit",
    "ai_digest",
    "webhooks",
    "unlimited",
    "branding",
)


@dataclass
class Entitlements:
    license: LicenseDocument
    features: set[str] = field(default_factory=set)
    note_limit: int | None = 25
    task_limit: int | None = 40
    edition_label: str = "Community Edition"

    def allows(self, feature: str) -> bool:
        return feature in self.features

    @property
    def enterprise(self) -> bool:
        return self.allows("enterprise.suite") or all(
            self.allows(name) for name in ("vault", "executive_reports", "audit")
        )


def _from_license(doc: LicenseDocument) -> Entitlements:
    features = set(doc.features)
    # Always grant the free surface.
    features.update({"notes", "tasks", "dashboard"})

    enterprise_granted = False
    if doc.valid and doc.is_enterprise_tier:
        enterprise_granted = True
    if doc.valid and "enterprise.suite" in features:
        enterprise_granted = True

    if enterprise_granted:
        features.update(ENTERPRISE_FEATURES)
        features.add("enterprise.suite")
        return Entitlements(
            license=doc,
            features=features,
            note_limit=None,
            task_limit=None,
            edition_label="Enterprise Edition",
        )

    return Entitlements(
        license=doc,
        features=features,
        note_limit=25,
        task_limit=40,
        edition_label="Community Edition",
    )


@lru_cache(maxsize=1)
def current_entitlements() -> Entitlements:
    return _from_license(load_license())


def refresh_entitlements() -> Entitlements:
    current_entitlements.cache_clear()
    return current_entitlements()
