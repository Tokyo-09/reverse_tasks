"""Runtime feature gates used by routes and services."""

from __future__ import annotations

from functools import wraps

from nexusforge.licensing.entitlements import current_entitlements


class FeatureLocked(PermissionError):
    def __init__(self, feature: str):
        self.feature = feature
        super().__init__(f"Feature '{feature}' requires an Enterprise entitlement")


def feature_allowed(feature: str) -> bool:
    return current_entitlements().allows(feature)


def require_feature(feature: str) -> None:
    if not feature_allowed(feature):
        raise FeatureLocked(feature)


def enterprise_route(feature: str):
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            require_feature(feature)
            return fn(*args, **kwargs)

        return wrapper

    return decorator
