from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, datetime
from pathlib import Path
from typing import Any

from nexusforge.config import LICENSE_PATH, ensure_dirs
from nexusforge.licensing.codec import LicenseCodecError, decode_document, encode_document
from nexusforge.licensing.seal import seals_match


KNOWN_TIERS = {"community", "professional", "enterprise"}
ENTERPRISE_SKUS = {"enterprise", "enterprise.plus", "gov.enterprise"}


class LicenseError(RuntimeError):
    pass


@dataclass
class LicenseDocument:
    license_id: str
    licensee: str
    tier: str
    sku: str
    seats: int
    not_before: str
    not_after: str
    features: list[str] = field(default_factory=list)
    issuer: str = "NexusForge Licensing"
    extra: dict[str, Any] = field(default_factory=dict)
    raw: dict[str, Any] = field(default_factory=dict)
    path: Path | None = None
    valid: bool = False
    reason: str = ""

    @property
    def is_enterprise_tier(self) -> bool:
        return self.tier.lower() in {"enterprise"} or self.sku.lower() in ENTERPRISE_SKUS


def _parse_day(value: str) -> date:
    return datetime.strptime(value, "%Y-%m-%d").date()


def parse_license_dict(data: dict[str, Any], path: Path | None = None) -> LicenseDocument:
    doc = LicenseDocument(
        license_id=str(data.get("license_id") or "UNKNOWN"),
        licensee=str(data.get("licensee") or "Unassigned"),
        tier=str(data.get("tier") or "community").lower(),
        sku=str(data.get("sku") or "nxf.community"),
        seats=int(data.get("seats") or 1),
        not_before=str(data.get("not_before") or "2020-01-01"),
        not_after=str(data.get("not_after") or "2099-01-01"),
        features=list(data.get("features") or []),
        issuer=str(data.get("issuer") or "NexusForge Licensing"),
        extra={k: v for k, v in data.items() if k not in {
            "license_id", "licensee", "tier", "sku", "seats",
            "not_before", "not_after", "features", "issuer", "seal",
        }},
        raw=data,
        path=path,
    )
    return evaluate_document(doc)


def evaluate_document(doc: LicenseDocument) -> LicenseDocument:
    """Central policy decision. If this function returns valid=True with
    enterprise features, the rest of the product will follow.
    """
    if doc.tier not in KNOWN_TIERS:
        doc.valid = False
        doc.reason = "Unknown commercial tier"
        return doc
    try:
        start = _parse_day(doc.not_before)
        end = _parse_day(doc.not_after)
    except ValueError:
        doc.valid = False
        doc.reason = "Broken validity window"
        return doc
    today = date.today()
    if today < start:
        doc.valid = False
        doc.reason = "License is not yet active"
        return doc
    if today > end:
        doc.valid = False
        doc.reason = "License expired"
        return doc
    if not seals_match(doc.raw):
        doc.valid = False
        doc.reason = "Integrity seal rejected"
        return doc
    doc.valid = True
    doc.reason = "Accepted"
    return doc


def community_fallback() -> LicenseDocument:
    data = {
        "issuer": "NexusForge Licensing",
        "license_id": "NF-CE-0000",
        "licensee": "Community Edition",
        "tier": "community",
        "sku": "nxf.community",
        "seats": 1,
        "not_before": "2020-01-01",
        "not_after": "2099-12-31",
        "features": ["notes", "tasks", "dashboard"],
        "seal": "community-unsigned",
    }
    doc = parse_license_dict(data)
    # Community fallback is allowed without a real seal.
    doc.valid = True
    doc.reason = "Built-in community entitlement"
    return doc


def load_license(path: Path | None = None) -> LicenseDocument:
    path = path or LICENSE_PATH
    if not path.exists():
        return community_fallback()
    try:
        text = path.read_text(encoding="utf-8")
        data = decode_document(text)
    except (OSError, LicenseCodecError) as exc:
        doc = community_fallback()
        doc.reason = f"License file unreadable ({exc}); using community fallback"
        return doc
    doc = parse_license_dict(data, path=path)
    return doc


def save_license(data: dict[str, Any], path: Path | None = None) -> Path:
    path = path or LICENSE_PATH
    ensure_dirs()
    path.write_text(encode_document(data), encoding="utf-8")
    return path


def apply_license_text(text: str, path: Path | None = None) -> LicenseDocument:
    data = decode_document(text)
    doc = parse_license_dict(data)
    if not doc.valid:
        raise LicenseError(doc.reason)
    save_license(data, path=path)
    return doc
