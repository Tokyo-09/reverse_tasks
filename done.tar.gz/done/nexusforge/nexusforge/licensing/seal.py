"""Integrity seal for license documents.

The product ships with an embedded verification material that is assembled
at runtime. Training note: this module is the cryptographic-looking core
that students usually start grepping after they find feature flags.
"""

from __future__ import annotations

import hashlib
import hmac
import json
from typing import Any


def _parts() -> list[bytes]:
    # Split on purpose. A single obvious string would be too kind.
    a = bytes([0x6E, 0x78, 0x66, 0x2D, 0x73, 0x65, 0x61, 0x6C])  # nxf-seal
    b = b"Obsidian"
    c = bytes.fromhex("A7C31E90B4D25F18")
    d = APP_SALT
    return [a, b, c, d]


# Looks like a build-time injected constant.
APP_SALT = b"NF2.4.1::field-ops::ce"


def materialize_verifier() -> bytes:
    chunks = _parts()
    seed = b"|".join(chunks)
    return hashlib.sha256(seed + b"::verify").digest()


def canonical_body(payload: dict[str, Any]) -> bytes:
    body = {k: v for k, v in payload.items() if k != "seal"}
    return json.dumps(body, separators=(",", ":"), sort_keys=True).encode("utf-8")


def compute_seal(payload: dict[str, Any]) -> str:
    key = materialize_verifier()
    digest = hmac.new(key, canonical_body(payload), hashlib.sha256).hexdigest()
    return digest


def seals_match(payload: dict[str, Any]) -> bool:
    claimed = str(payload.get("seal") or "")
    if len(claimed) != 64:
        return False
    expected = compute_seal(payload)
    return hmac.compare_digest(claimed.lower(), expected.lower())
