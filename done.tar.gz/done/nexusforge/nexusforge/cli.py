from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from rich.console import Console
from rich.table import Table

from nexusforge import __version__
from nexusforge.config import LICENSE_PATH
from nexusforge.database import init_db
from nexusforge.licensing.codec import encode_document
from nexusforge.licensing.engine import apply_license_text, load_license
from nexusforge.licensing.entitlements import current_entitlements, refresh_entitlements
from nexusforge.licensing.seal import compute_seal
from nexusforge.services.seed import seed_if_empty

console = Console()


def cmd_info(_: argparse.Namespace) -> int:
    ent = current_entitlements()
    lic = ent.license
    table = Table(title=f"NexusForge {__version__}")
    table.add_column("Field")
    table.add_column("Value")
    table.add_row("Edition", ent.edition_label)
    table.add_row("License ID", lic.license_id)
    table.add_row("Licensee", lic.licensee)
    table.add_row("Tier / SKU", f"{lic.tier} / {lic.sku}")
    table.add_row("Valid", f"{lic.valid} ({lic.reason})")
    table.add_row("Window", f"{lic.not_before} → {lic.not_after}")
    table.add_row("Features", ", ".join(sorted(ent.features)))
    table.add_row("License file", str(lic.path or LICENSE_PATH))
    console.print(table)
    return 0


def cmd_serve(args: argparse.Namespace) -> int:
    import uvicorn

    init_db()
    seed_if_empty()
    uvicorn.run("nexusforge.app:app", host=args.host, port=args.port, reload=args.reload)
    return 0


def cmd_activate(args: argparse.Namespace) -> int:
    text = Path(args.file).read_text(encoding="utf-8")
    try:
        apply_license_text(text)
        refresh_entitlements()
    except Exception as exc:  # noqa: BLE001
        console.print(f"[red]Activation failed:[/red] {exc}")
        return 1
    console.print("[green]License accepted.[/green]")
    return cmd_info(args)


def cmd_mint(args: argparse.Namespace) -> int:
    """Instructor / vendor tool. Ships with the tree on purpose."""
    payload = {
        "issuer": "NexusForge Licensing",
        "license_id": args.license_id,
        "licensee": args.licensee,
        "tier": args.tier,
        "sku": args.sku,
        "seats": args.seats,
        "not_before": args.not_before,
        "not_after": args.not_after,
        "features": [f.strip() for f in args.features.split(",") if f.strip()],
    }
    payload["seal"] = compute_seal(payload)
    blob = encode_document(payload)
    if args.output:
        Path(args.output).write_text(blob, encoding="utf-8")
        console.print(f"Wrote {args.output}")
    else:
        sys.stdout.write(blob)
    if args.json:
        console.print(json.dumps(payload, indent=2))
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="nexusforge", description="NexusForge platform CLI")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_info = sub.add_parser("info", help="Show edition and license")
    p_info.set_defaults(func=cmd_info)

    p_serve = sub.add_parser("serve", help="Run the web workspace")
    p_serve.add_argument("--host", default="127.0.0.1")
    p_serve.add_argument("--port", type=int, default=8040)
    p_serve.add_argument("--reload", action="store_true")
    p_serve.set_defaults(func=cmd_serve)

    p_act = sub.add_parser("activate", help="Install a .nfx license file")
    p_act.add_argument("file")
    p_act.set_defaults(func=cmd_activate)

    p_mint = sub.add_parser("mint", help="Issue a signed license (vendor tooling)")
    p_mint.add_argument("--licensee", default="Internal Lab")
    p_mint.add_argument("--license-id", default="NF-ENT-LAB-0001")
    p_mint.add_argument("--tier", default="enterprise")
    p_mint.add_argument("--sku", default="nxf.enterprise")
    p_mint.add_argument("--seats", type=int, default=25)
    p_mint.add_argument("--not-before", default="2024-01-01")
    p_mint.add_argument("--not-after", default="2028-12-31")
    p_mint.add_argument("--features", default="enterprise.suite,vault,executive_reports,audit,ai_digest,webhooks,unlimited,branding")
    p_mint.add_argument("-o", "--output")
    p_mint.add_argument("--json", action="store_true")
    p_mint.set_defaults(func=cmd_mint)

    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
