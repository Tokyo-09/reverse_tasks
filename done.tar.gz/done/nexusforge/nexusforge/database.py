from __future__ import annotations

from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, sessionmaker

from nexusforge.config import DB_PATH, ensure_dirs


class Base(DeclarativeBase):
    pass


_engine = None
SessionLocal = None


def get_engine():
    global _engine, SessionLocal
    if _engine is None:
        ensure_dirs()
        _engine = create_engine(
            f"sqlite:///{DB_PATH}",
            connect_args={"check_same_thread": False},
            echo=False,
        )
        SessionLocal = sessionmaker(bind=_engine, autoflush=False, autocommit=False)
    return _engine


def init_db() -> None:
    from nexusforge import models  # noqa: F401

    engine = get_engine()
    Base.metadata.create_all(bind=engine)


def get_session():
    get_engine()
    return SessionLocal()
