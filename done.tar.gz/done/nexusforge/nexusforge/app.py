from __future__ import annotations

from fastapi import FastAPI, Form, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from nexusforge import __version__
from nexusforge.config import APP_CODENAME, APP_NAME, STATIC_DIR, TEMPLATES_DIR, ensure_dirs
from nexusforge.database import init_db
from nexusforge.licensing.codec import LicenseCodecError
from nexusforge.licensing.engine import LicenseError, apply_license_text
from nexusforge.licensing.entitlements import current_entitlements, refresh_entitlements
from nexusforge.licensing.gates import FeatureLocked, enterprise_route
from nexusforge.services import intel, workspace
from nexusforge.services.seed import seed_if_empty

templates = Jinja2Templates(directory=str(TEMPLATES_DIR))


def _ctx(request: Request, **extra):
    ent = current_entitlements()
    stats = workspace.workspace_stats()
    data = {
        "request": request,
        "app_name": APP_NAME,
        "version": __version__,
        "codename": APP_CODENAME,
        "ent": ent,
        "lic": ent.license,
        "stats": stats,
        "flash": request.query_params.get("flash"),
        "error": request.query_params.get("error"),
    }
    data.update(extra)
    return data


def create_app() -> FastAPI:
    ensure_dirs()
    init_db()
    seed_if_empty()

    app = FastAPI(title=APP_NAME, version=__version__, docs_url="/api/docs", redoc_url=None)
    app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")

    @app.exception_handler(FeatureLocked)
    async def locked_handler(request: Request, exc: FeatureLocked):
        if request.url.path.startswith("/api/"):
            return JSONResponse(
                status_code=402,
                content={"error": "enterprise_required", "feature": exc.feature},
            )
        return RedirectResponse(url=f"/upgrade?feature={exc.feature}", status_code=303)

    @app.get("/", response_class=HTMLResponse)
    async def dashboard(request: Request):
        return templates.TemplateResponse(request, "dashboard.html", _ctx(request))

    @app.get("/notes", response_class=HTMLResponse)
    async def notes_page(request: Request):
        include_vault = current_entitlements().allows("vault")
        notes = workspace.list_notes(include_vault=include_vault)
        return templates.TemplateResponse(request, "notes.html", _ctx(request, notes=notes))

    @app.post("/notes")
    async def notes_create(
        title: str = Form(...),
        body: str = Form(""),
        tags: str = Form(""),
        vaulted: str = Form(""),
    ):
        try:
            workspace.create_note(title, body, tags, vaulted=vaulted == "on")
        except FeatureLocked as exc:
            return RedirectResponse(url=f"/upgrade?feature={exc.feature}", status_code=303)
        return RedirectResponse(url="/notes?flash=Заметка+сохранена", status_code=303)

    @app.post("/notes/{note_id}/delete")
    async def notes_delete(note_id: int):
        workspace.delete_note(note_id)
        return RedirectResponse(url="/notes?flash=Удалено", status_code=303)

    @app.get("/tasks", response_class=HTMLResponse)
    async def tasks_page(request: Request):
        tasks = workspace.list_tasks()
        return templates.TemplateResponse(request, "tasks.html", _ctx(request, tasks=tasks))

    @app.post("/tasks")
    async def tasks_create(
        title: str = Form(...),
        priority: str = Form("normal"),
        due: str = Form(""),
    ):
        try:
            workspace.create_task(title, priority, due)
        except FeatureLocked as exc:
            return RedirectResponse(url=f"/upgrade?feature={exc.feature}", status_code=303)
        return RedirectResponse(url="/tasks?flash=Задача+создана", status_code=303)

    @app.post("/tasks/{task_id}/status")
    async def tasks_status(task_id: int, status: str = Form(...)):
        workspace.set_task_status(task_id, status)
        return RedirectResponse(url="/tasks", status_code=303)

    @app.get("/vault", response_class=HTMLResponse)
    @enterprise_route("vault")
    async def vault_page(request: Request):
        notes = [n for n in workspace.list_notes(include_vault=True) if n.vaulted]
        return templates.TemplateResponse(request, "vault.html", _ctx(request, notes=notes))

    @app.get("/reports", response_class=HTMLResponse)
    @enterprise_route("executive_reports")
    async def reports_page(request: Request):
        report = intel.build_executive_report()
        return templates.TemplateResponse(request, "reports.html", _ctx(request, report=report))

    @app.get("/intel", response_class=HTMLResponse)
    @enterprise_route("ai_digest")
    async def intel_page(request: Request):
        digest = intel.build_ai_digest()
        return templates.TemplateResponse(request, "intel.html", _ctx(request, digest=digest))

    @app.get("/audit", response_class=HTMLResponse)
    @enterprise_route("audit")
    async def audit_page(request: Request):
        events = workspace.list_audit()
        return templates.TemplateResponse(request, "audit.html", _ctx(request, events=events))

    @app.get("/webhooks", response_class=HTMLResponse)
    @enterprise_route("webhooks")
    async def webhooks_page(request: Request):
        hooks = workspace.list_webhooks()
        return templates.TemplateResponse(request, "webhooks.html", _ctx(request, hooks=hooks))

    @app.post("/webhooks")
    @enterprise_route("webhooks")
    async def webhooks_create(
        name: str = Form(...),
        target_url: str = Form(...),
        secret: str = Form(""),
    ):
        workspace.create_webhook(name, target_url, secret)
        return RedirectResponse(url="/webhooks?flash=Webhook+добавлен", status_code=303)

    @app.get("/license", response_class=HTMLResponse)
    async def license_page(request: Request):
        return templates.TemplateResponse(request, "license.html", _ctx(request))

    @app.post("/license/activate")
    async def license_activate(blob: str = Form(...)):
        try:
            apply_license_text(blob)
            refresh_entitlements()
        except (LicenseError, LicenseCodecError) as exc:
            return RedirectResponse(url=f"/license?error={str(exc)}", status_code=303)
        return RedirectResponse(url="/license?flash=Лицензия+принята", status_code=303)

    @app.get("/upgrade", response_class=HTMLResponse)
    async def upgrade_page(request: Request, feature: str = "enterprise.suite"):
        return templates.TemplateResponse(request, "upgrade.html", _ctx(request, feature=feature))

    @app.get("/api/health")
    async def health():
        ent = current_entitlements()
        return {
            "product": APP_NAME,
            "version": __version__,
            "edition": ent.edition_label,
            "license_id": ent.license.license_id,
            "valid": ent.license.valid,
        }

    @app.get("/api/digest")
    @enterprise_route("ai_digest")
    async def api_digest():
        return intel.build_ai_digest()

    @app.get("/api/report")
    @enterprise_route("executive_reports")
    async def api_report():
        return intel.build_executive_report()

    return app


app = create_app()
