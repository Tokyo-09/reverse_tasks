"""NexusForge Community Edition."""

__version__ = "2.4.1"
__edition__ = "community"
__product__ = "NexusForge"
