from __future__ import annotations

import os
from pathlib import Path

APP_NAME = "NexusForge"
APP_VERSION = "2.4.1"
APP_CODENAME = "Obsidian"

ROOT_DIR = Path(__file__).resolve().parent.parent
PACKAGE_DIR = Path(__file__).resolve().parent
DATA_DIR = Path(os.environ.get("NEXUSFORGE_DATA", ROOT_DIR / "var")).resolve()
TEMPLATES_DIR = PACKAGE_DIR / "web" / "templates"
STATIC_DIR = PACKAGE_DIR / "web" / "static"
LICENSE_PATH = Path(os.environ.get("NEXUSFORGE_LICENSE", DATA_DIR / "license.nfx")).resolve()
DB_PATH = Path(os.environ.get("NEXUSFORGE_DB", DATA_DIR / "nexusforge.db")).resolve()
SECRET_FILE = DATA_DIR / ".instance_secret"

FREE_NOTE_LIMIT = 25
FREE_TASK_LIMIT = 40


def ensure_dirs() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    (DATA_DIR / "exports").mkdir(exist_ok=True)
    (DATA_DIR / "vault").mkdir(exist_ok=True)
