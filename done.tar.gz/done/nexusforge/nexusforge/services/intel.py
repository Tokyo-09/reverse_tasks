"""Enterprise-only intelligence layer (fully local, no external model)."""

from __future__ import annotations

from collections import Counter
import re

from nexusforge.licensing.gates import require_feature
from nexusforge.services.workspace import list_notes, list_tasks


WORD_RE = re.compile(r"[A-Za-zА-Яа-яЁё0-9_-]{3,}")


def build_ai_digest() -> dict:
    require_feature("ai_digest")
    notes = list_notes(include_vault=True)
    tasks = list_tasks()
    blob = " ".join(f"{n.title} {n.body} {n.tags}" for n in notes)
    words = [w.lower() for w in WORD_RE.findall(blob)]
    common = Counter(words).most_common(12)
    open_tasks = [t for t in tasks if t.status == "open"]
    high = [t for t in open_tasks if t.priority == "high"]
    themes = [w for w, _ in common[:6]] or ["(недостаточно данных)"]
    summary = (
        f"В рабочем пространстве {len(notes)} заметок и {len(tasks)} задач "
        f"({len(open_tasks)} открытых, из них {len(high)} с высоким приоритетом). "
        f"Доминирующие темы: {', '.join(themes)}."
    )
    actions = []
    if high:
        actions.append(f"Закрыть высокий приоритет: {high[0].title}")
    if notes:
        actions.append("Собрать executive report по текущим темам")
    if len(notes) >= 5:
        actions.append("Вынести чувствительные заметки в Secure Vault")
    return {
        "summary": summary,
        "themes": themes,
        "word_weights": common,
        "actions": actions or ["Добавьте больше заметок — дайджест станет точнее"],
        "notes_considered": len(notes),
    }


def build_executive_report() -> dict:
    require_feature("executive_reports")
    notes = list_notes(include_vault=True)
    tasks = list_tasks()
    digest = None
    try:
        digest = build_ai_digest()
    except Exception:
        digest = {"summary": "Дайджест недоступен", "themes": [], "actions": []}
    status_counts = Counter(t.status for t in tasks)
    prio_counts = Counter(t.priority for t in tasks)
    return {
        "title": "NexusForge Executive Briefing",
        "digest": digest,
        "notes": [
            {
                "title": n.title,
                "tags": n.tags,
                "vaulted": n.vaulted,
                "updated": n.updated_at.strftime("%Y-%m-%d %H:%M"),
                "excerpt": (n.body or "")[:280],
            }
            for n in notes[:30]
        ],
        "tasks": {
            "by_status": dict(status_counts),
            "by_priority": dict(prio_counts),
            "open": [
                {"title": t.title, "priority": t.priority, "due": t.due}
                for t in tasks
                if t.status == "open"
            ][:20],
        },
    }
