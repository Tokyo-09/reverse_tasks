from __future__ import annotations

from nexusforge.database import get_session
from nexusforge.models import Note, Task


def seed_if_empty() -> None:
    session = get_session()
    try:
        if session.query(Note).count() > 0:
            return
        notes = [
            Note(
                title="Онбординг команды",
                body="Чеклист: доступ в репозиторий, локальный стенд NexusForge, договорённости по тегам заметок.",
                tags="ops,onboarding",
                pinned=True,
            ),
            Note(
                title="Инцидент 14:22 — очередь отчётов",
                body="Пользователи Community упираются в лимит экспорта. Эскалировать в enterprise-очередь?",
                tags="incident,reports",
            ),
            Note(
                title="Черновик Q3 briefing",
                body="Сфокусироваться на retention, времени закрытия задач и доле vault-заметок.",
                tags="exec,q3",
            ),
            Note(
                title="Секретный ключ стенда",
                body="Не коммитить. Ротация раз в квартал. Это учебная запись для модуля Secure Vault.",
                tags="secret,infra",
                vaulted=True,
            ),
            Note(
                title="Идеи по интеграциям",
                body="Webhook на создание high-priority задач. Slack incoming — только в Enterprise.",
                tags="integrations",
            ),
        ]
        tasks = [
            Task(title="Подготовить демо для тренинга", status="open", priority="high", due="2026-09-12"),
            Task(title="Разобрать backlog заметок", status="open", priority="normal", due=""),
            Task(title="Обновить README Community Edition", status="done", priority="low", due=""),
            Task(title="Проверить экспорт executive report", status="open", priority="high", due="2026-09-15"),
        ]
        session.add_all(notes + tasks)
        session.commit()
    finally:
        session.close()
