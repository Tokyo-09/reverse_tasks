from __future__ import annotations

from datetime import datetime

from nexusforge.database import get_session
from nexusforge.licensing.entitlements import current_entitlements
from nexusforge.licensing.gates import FeatureLocked
from nexusforge.models import AuditEvent, Note, Task, Webhook


def _audit(session, action: str, detail: str) -> None:
    ent = current_entitlements()
    if not ent.allows("audit"):
        return
    session.add(AuditEvent(action=action, detail=detail))


def list_notes(include_vault: bool = False) -> list[Note]:
    session = get_session()
    try:
        q = session.query(Note).order_by(Note.pinned.desc(), Note.updated_at.desc())
        if not include_vault or not current_entitlements().allows("vault"):
            q = q.filter(Note.vaulted.is_(False))
        return list(q.all())
    finally:
        session.close()


def get_note(note_id: int) -> Note | None:
    session = get_session()
    try:
        note = session.get(Note, note_id)
        if note and note.vaulted and not current_entitlements().allows("vault"):
            return None
        return note
    finally:
        session.close()


def create_note(title: str, body: str, tags: str = "", vaulted: bool = False) -> Note:
    ent = current_entitlements()
    session = get_session()
    try:
        count = session.query(Note).count()
        if ent.note_limit is not None and count >= ent.note_limit:
            raise FeatureLocked("unlimited")
        if vaulted:
            if not ent.allows("vault"):
                raise FeatureLocked("vault")
        note = Note(
            title=title.strip() or "Untitled",
            body=body,
            tags=tags,
            vaulted=vaulted,
            updated_at=datetime.utcnow(),
        )
        session.add(note)
        _audit(session, "note.create", note.title)
        session.commit()
        session.refresh(note)
        return note
    finally:
        session.close()


def update_note(note_id: int, title: str, body: str, tags: str, pinned: bool, vaulted: bool) -> Note:
    ent = current_entitlements()
    if vaulted and not ent.allows("vault"):
        raise FeatureLocked("vault")
    session = get_session()
    try:
        note = session.get(Note, note_id)
        if note is None:
            raise KeyError(note_id)
        note.title = title.strip() or note.title
        note.body = body
        note.tags = tags
        note.pinned = pinned
        note.vaulted = vaulted
        note.updated_at = datetime.utcnow()
        _audit(session, "note.update", note.title)
        session.commit()
        session.refresh(note)
        return note
    finally:
        session.close()


def delete_note(note_id: int) -> None:
    session = get_session()
    try:
        note = session.get(Note, note_id)
        if note is None:
            return
        _audit(session, "note.delete", note.title)
        session.delete(note)
        session.commit()
    finally:
        session.close()


def list_tasks() -> list[Task]:
    session = get_session()
    try:
        return list(session.query(Task).order_by(Task.id.desc()).all())
    finally:
        session.close()


def create_task(title: str, priority: str = "normal", due: str = "") -> Task:
    ent = current_entitlements()
    session = get_session()
    try:
        count = session.query(Task).count()
        if ent.task_limit is not None and count >= ent.task_limit:
            raise FeatureLocked("unlimited")
        task = Task(title=title.strip() or "Task", priority=priority, due=due)
        session.add(task)
        _audit(session, "task.create", task.title)
        session.commit()
        session.refresh(task)
        return task
    finally:
        session.close()


def set_task_status(task_id: int, status: str) -> Task:
    session = get_session()
    try:
        task = session.get(Task, task_id)
        if task is None:
            raise KeyError(task_id)
        task.status = status
        _audit(session, "task.status", f"{task.title} -> {status}")
        session.commit()
        session.refresh(task)
        return task
    finally:
        session.close()


def list_audit(limit: int = 200) -> list[AuditEvent]:
    if not current_entitlements().allows("audit"):
        raise FeatureLocked("audit")
    session = get_session()
    try:
        return list(session.query(AuditEvent).order_by(AuditEvent.id.desc()).limit(limit).all())
    finally:
        session.close()


def list_webhooks() -> list[Webhook]:
    if not current_entitlements().allows("webhooks"):
        raise FeatureLocked("webhooks")
    session = get_session()
    try:
        return list(session.query(Webhook).order_by(Webhook.id.desc()).all())
    finally:
        session.close()


def create_webhook(name: str, target_url: str, secret: str = "") -> Webhook:
    if not current_entitlements().allows("webhooks"):
        raise FeatureLocked("webhooks")
    session = get_session()
    try:
        hook = Webhook(name=name, target_url=target_url, secret=secret)
        session.add(hook)
        _audit(session, "webhook.create", name)
        session.commit()
        session.refresh(hook)
        return hook
    finally:
        session.close()


def workspace_stats() -> dict:
    session = get_session()
    try:
        notes = session.query(Note).count()
        vaulted = session.query(Note).filter(Note.vaulted.is_(True)).count()
        tasks = session.query(Task).count()
        open_tasks = session.query(Task).filter(Task.status == "open").count()
        return {
            "notes": notes,
            "vaulted": vaulted,
            "tasks": tasks,
            "open_tasks": open_tasks,
        }
    finally:
        session.close()
