community.nfx            — можно отдавать студентам
enterprise.forged.nfx    — можно отдавать; печать заведомо битая
enterprise.valid.nfx     — только инструктору; перед раздачей удалите из архива
