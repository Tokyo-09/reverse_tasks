# VaultDesk — Reverse Engineering Lab

## Difficulty

Beginner / intermediate.

Estimated solving time: 30–60 minutes.

## Goal

The application contains an Advanced Diagnostics panel.

Your task is to make the application enter the Administrator state and
make the Advanced Diagnostics button usable.

You receive only `VaultDesk.exe`.

Do NOT use the source code while solving.

## Rules

Allowed:

- Ghidra
- IDA
- x64dbg
- debugger/disassembler
- binary patching

Not required:

- keygen
- brute force
- cryptography
- XOR
- networking

## Initial observations

The GUI contains:

    Username: [____________] [Login]

    Status: Guest

    [Advanced diagnostics]

The diagnostics button is initially disabled.

Try interacting with the application before opening the binary.

## Objectives

1. Identify the function responsible for determining the user's role.
2. Determine why entering `admin` does not produce Administrator.
3. Identify the branch that controls the Advanced Diagnostics button.
4. Patch the executable so `admin` results in Administrator.
5. Verify that the patched application enables Advanced Diagnostics.
6. Explain your patch in terms of assembly/control flow.

## Bonus

Find two different valid patches that produce the same behavior.

For example:

- patch the role assignment;
- patch a conditional branch.

Do not simply replace the entire program with a different executable.

## Deliverable

Submit:

- patched executable;
- screenshot showing Administrator;
- short explanation of the patched instruction(s).
