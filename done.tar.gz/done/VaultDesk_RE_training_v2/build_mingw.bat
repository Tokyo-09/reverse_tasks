@echo off
where g++ >nul 2>nul
if errorlevel 1 (
    echo MinGW-w64 g++ was not found.
    echo Install MinGW-w64 and make sure g++ is in PATH.
    pause
    exit /b 1
)

g++ -std=c++17 -O0 -s -municode VaultDesk.cpp -o VaultDesk.exe -mwindows -static-libgcc -static-libstdc++

if errorlevel 1 (
    echo Build failed.
    pause
    exit /b 1
)

echo.
echo Build successful: VaultDesk.exe
pause
