#define UNICODE
#define _UNICODE
#include <windows.h>
#include <string>

static HWND g_status;
static HWND g_user;
static HWND g_advanced;

enum Role {
    ROLE_GUEST = 0,
    ROLE_USER = 1,
    ROLE_ADMIN = 2
};

static Role GetRole(const std::wstring& username) {
    if (username == L"operator")
        return ROLE_USER;

    if (username == L"admin")
        return ROLE_USER; // Training bug: admin is intentionally assigned USER.

    return ROLE_GUEST;
}

static void UpdateUI() {
    std::wstring username;
    int n = GetWindowTextLengthW(g_user);
    username.resize(n);
    if (n > 0)
        GetWindowTextW(g_user, username.data(), n + 1);

    Role role = GetRole(username);

    if (role == ROLE_ADMIN) {
        SetWindowTextW(g_status, L"Status: Administrator");
        EnableWindow(g_advanced, TRUE);
    } else if (role == ROLE_USER) {
        SetWindowTextW(g_status, L"Status: Standard user");
        EnableWindow(g_advanced, FALSE);
    } else {
        SetWindowTextW(g_status, L"Status: Guest");
        EnableWindow(g_advanced, FALSE);
    }
}

static void ShowAdvanced() {
    MessageBoxW(
        nullptr,
        L"Advanced diagnostics\n\n"
        L"Build: TRAINING\n"
        L"Role: Administrator\n"
        L"Diagnostics: enabled",
        L"VaultDesk",
        MB_OK | MB_ICONINFORMATION
    );
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
    case WM_CREATE:
        CreateWindowW(
            L"STATIC", L"VaultDesk — role management training",
            WS_CHILD | WS_VISIBLE,
            20, 15, 390, 25, hwnd, nullptr, nullptr, nullptr
        );

        CreateWindowW(
            L"STATIC", L"Username:",
            WS_CHILD | WS_VISIBLE,
            20, 60, 80, 20, hwnd, nullptr, nullptr, nullptr
        );

        g_user = CreateWindowW(
            L"EDIT", L"",
            WS_CHILD | WS_VISIBLE | WS_BORDER | ES_AUTOHSCROLL,
            100, 57, 220, 25, hwnd, nullptr, nullptr, nullptr
        );

        CreateWindowW(
            L"BUTTON", L"Login",
            WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
            330, 57, 100, 25, hwnd, (HMENU)1001, nullptr, nullptr
        );

        g_status = CreateWindowW(
            L"STATIC", L"Status: Guest",
            WS_CHILD | WS_VISIBLE,
            20, 105, 410, 25, hwnd, nullptr, nullptr, nullptr
        );

        g_advanced = CreateWindowW(
            L"BUTTON", L"Advanced diagnostics",
            WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
            20, 145, 190, 30, hwnd, (HMENU)1002, nullptr, nullptr
        );

        EnableWindow(g_advanced, FALSE);
        break;

    case WM_COMMAND:
        if (LOWORD(wParam) == 1001) {
            UpdateUI();
        } else if (LOWORD(wParam) == 1002) {
            ShowAdvanced();
        }
        break;

    case WM_DESTROY:
        PostQuitMessage(0);
        break;
    }

    return DefWindowProcW(hwnd, msg, wParam, lParam);
}

int WINAPI wWinMain(HINSTANCE hInst, HINSTANCE, PWSTR, int nCmdShow) {
    const wchar_t CLASS_NAME[] = L"VaultDeskTrainingV2";

    WNDCLASSW wc{};
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInst;
    wc.lpszClassName = CLASS_NAME;
    wc.hCursor = LoadCursorW(nullptr, IDC_ARROW);
    wc.hbrBackground = reinterpret_cast<HBRUSH>(COLOR_WINDOW + 1);

    RegisterClassW(&wc);

    HWND hwnd = CreateWindowW(
        CLASS_NAME,
        L"VaultDesk",
        WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX,
        CW_USEDEFAULT, CW_USEDEFAULT,
        470, 230,
        nullptr, nullptr, hInst, nullptr
    );

    ShowWindow(hwnd, nCmdShow);
    UpdateWindow(hwnd);

    MSG msg{};
    while (GetMessageW(&msg, nullptr, 0, 0) > 0) {
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }

    return 0;
}
