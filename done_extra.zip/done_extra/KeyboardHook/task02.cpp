#define WIN32_LEAN_AND_MEAN
#include <windows.h>

HHOOK hHook;
int seq_index = 0;
// Expected sequence: P -> A -> T -> C -> H
DWORD expected_keys[] = { 'P', 'A', 'T', 'C', 'H' };
HWND hStatic;

LRESULT CALLBACK KeyboardProc(int nCode, WPARAM wParam, LPARAM lParam) {
    if (nCode == HC_ACTION && wParam == WM_KEYDOWN) {
        KBDLLHOOKSTRUCT* pKey = (KBDLLHOOKSTRUCT*)lParam;

        // Reset if the wrong key is pressed
        if (pKey->vkCode != expected_keys[seq_index]) {
            seq_index = 0;
            // If starting over, but the first letter is correct, don't reset completely
            if (pKey->vkCode == expected_keys[0]) {
                seq_index = 1;
            }
            SetWindowTextA(hStatic, "Waiting... (Reset)");
            return CallNextHookEx(hHook, nCode, wParam, lParam);
        }

        seq_index++;

        if (seq_index == 1) SetWindowTextA(hStatic, "Keep typing...");
        if (seq_index == 3) SetWindowTextA(hStatic, "Almost there...");

        // If the whole sequence is entered
        if (seq_index == 5) {
            SetWindowTextA(hStatic, "Access granted!");
            MessageBoxA(NULL, "Success! Flag: FLAG{H00ks_4r3_W4tch1ng_Y0u}", "Success", MB_ICONINFORMATION);
            seq_index = 0; // Reset for re-entry
        }
    }
    return CallNextHookEx(hHook, nCode, wParam, lParam);
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
        case WM_CREATE:
            hStatic = CreateWindowExA(0, "STATIC", "Waiting...",
                                      WS_CHILD | WS_VISIBLE | SS_CENTER,
                                      20, 20, 260, 30, hwnd, NULL, NULL, NULL);

            // Install the hook
            hHook = SetWindowsHookExA(WH_KEYBOARD_LL, KeyboardProc, GetModuleHandle(NULL), 0);
            return 0;

        case WM_DESTROY:
            UnhookWindowsHookEx(hHook);
            PostQuitMessage(0);
            return 0;
    }
    return DefWindowProcA(hwnd, msg, wParam, lParam);
}

int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrev, LPSTR cmd, int nShow) {
    WNDCLASSEXA wc = {0};
    wc.cbSize = sizeof(WNDCLASSEXA);
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInst;
    wc.lpszClassName = "InvisibleListener";
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    RegisterClassExA(&wc);

    HWND hwnd = CreateWindowExA(0, "InvisibleListener", "Monitoring System",
                                WS_OVERLAPPEDWINDOW & ~WS_THICKFRAME & ~WS_MAXIMIZEBOX,
                                CW_USEDEFAULT, CW_USEDEFAULT, 320, 120, NULL, NULL, hInst, NULL);

    ShowWindow(hwnd, nShow);
    UpdateWindow(hwnd);

    MSG msg;
    while (GetMessageA(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessageA(&msg);
    }
    return 0;
}
