AntiDebugLab RE Training
=========================

Windows console PE challenge.

Файлы:
- challenge.cpp
- README_STUDENT.txt
- SOLUTION_TEACHER.txt
- build.sh

Сборка на Linux:
----------------
sudo apt install mingw-w64
./build.sh

Получатся:
- AntiDebugLab.exe
- AntiDebugLab_debug.exe

Рекомендуется начинать с AntiDebugLab.exe.

Инструменты:
- Ghidra
- x64dbg
- strings
- objdump / llvm-objdump (опционально)

Challenge намеренно не использует:
- сеть
- криптографию
- XOR
- упаковщики
- VMProtect/Themida
- инъекцию
- persistence
- credential theft
