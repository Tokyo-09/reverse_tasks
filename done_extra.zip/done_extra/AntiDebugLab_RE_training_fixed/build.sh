#!/usr/bin/env bash
set -euo pipefail
CXX="${CXX:-x86_64-w64-mingw32-g++}"

"$CXX" -std=c++17 -O0 -s -static -static-libgcc -static-libstdc++ \
    -mconsole "challenge.cpp" -o "AntiDebugLab.exe"

"$CXX" -std=c++17 -O0 -g -static -static-libgcc -static-libstdc++ \
    -mconsole "challenge.cpp" -o "AntiDebugLab_debug.exe"

echo "[+] Built AntiDebugLab.exe and AntiDebugLab_debug.exe"
file "AntiDebugLab.exe" "AntiDebugLab_debug.exe"
