#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <iostream>
#include <string>

// --- ТВОЙ АНТИ-ОТЛАДОЧНЫЙ КОД (БЕЗ ИЗМЕНЕНИЙ) ---
static bool api_debugger_check()
{
    return IsDebuggerPresent() != 0;
}

#if defined(__GNUC__) && defined(__x86_64__)
static bool peb_check_gcc_x64()
{
    void* peb = nullptr;
    asm volatile ("movq %%gs:0x60, %0" : "=r"(peb));
    BYTE beingDebugged = *reinterpret_cast<BYTE*>(
        reinterpret_cast<unsigned char*>(peb) + 0x2);
    return beingDebugged != 0;
}
#else
static bool peb_check_gcc_x64()
{
    return false;
}
#endif

static bool debugger_detected()
{
    if (api_debugger_check())
        return true;

    if (peb_check_gcc_x64())
        return true;

    return false;
}
// -----------------------------------------------

// Функция для генерации фейкового флага (выводится при обычном запуске)
std::string get_fake_flag() {
    return "FLAG{y0u_4r3_n0t_a_h4ck3r}";
}

// Функция для генерации настоящего флага (скрыта за анти-отладкой)
std::string get_real_flag() {
    // Настоящий флаг: "FLAG{p4tch_th3_p3b}"
    // Каждый символ здесь сдвинут на -1, чтобы скрыть его от утилиты strings
    std::string base = "EK@Fzo3sbg^sg2^o2a|";
    std::string real_flag = "";
    for (char c : base) {
        real_flag += (c + 1);
    }
    return real_flag;
}

int main()
{
    std::cout << "========================\n";
    std::cout << "      AntiDebugLab\n";
    std::cout << "========================\n\n";

    std::cout << "Checking environment...\n\n";

    const bool detected = debugger_detected();

    if (detected)
    {
        std::cout << "[-] Debugger detected\n";
        std::cout << "[-] Challenge locked\n";
        // В отладчике программа просто выходит, не показывая флаг
        return 1;
    }
    else
    {
        std::cout << "[+] Environment OK\n";
        std::cout << "[+] Challenge unlocked\n\n";

        // При обычном запуске показываем фейковый флаг
        std::cout << "Your flag: " << get_fake_flag() << "\n";
        return 0;
    }
}
