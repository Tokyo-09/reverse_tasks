#include <iostream>
#include <string>
#include <cctype>

static bool check_username(const std::string& username)
{
    if (username.size() != 5)
        return false;

    if (username[0] != 'r')
        return false;

    if (username[4] != 't')
        return false;

    return true;
}

static bool check_code(const std::string& code)
{
    if (code.size() != 4)
        return false;

    for (char c : code)
    {
        if (!std::isdigit(static_cast<unsigned char>(c)))
            return false;
    }

    int a = code[0] - '0';
    int b = code[1] - '0';
    int c = code[2] - '0';
    int d = code[3] - '0';

    if (a + c != 10)
        return false;

    if (b - d != 2)
        return false;

    if (a <= d)
        return false;

    if (b + c != 11)
        return false;

    return true;
}

static bool validate(const std::string& username, const std::string& code)
{
    if (!check_username(username))
        return false;

    if (!check_code(code))
        return false;

    return true;
}

int main()
{
    std::string username;
    std::string code;

    std::cout << "================================\n";
    std::cout << "          WinCheck v1.0         \n";
    std::cout << "================================\n\n";

    std::cout << "Enter username: ";
    std::cin >> username;

    std::cout << "Enter access code: ";
    std::cin >> code;

    std::cout << "\nChecking...\n\n";

    if (validate(username, code))
        std::cout << "Access granted!\n";
    else
        std::cout << "Access denied!\n";

    return 0;
}
