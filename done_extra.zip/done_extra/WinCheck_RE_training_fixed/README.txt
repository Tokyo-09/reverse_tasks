WinCheck RE Training
=====================

Набор для reverse engineering на Windows.

Файлы:
- WinCheck.exe          — stripped/release challenge
- WinCheck_debug.exe    — debug/учебная версия, если собрана
- challenge.cpp         — исходник для преподавателя
- README_STUDENT.txt    — задание
- SOLUTION_TEACHER.txt  — решение
- build.sh              — сборка под Linux через MinGW-w64

Рекомендуемый workflow:
1. Сначала использовать WinCheck.exe.
2. Ghidra -> Auto Analyze.
3. Search -> Strings.
4. XREF от "Access granted!".
5. Восстановить validate().
6. Решить условия вручную.
7. Проверить запуском под Windows/Wine.
