#!/usr/bin/env bash
set -euo pipefail
CXX="${CXX:-x86_64-w64-mingw32-g++}"

"$CXX" -std=c++17 -O0 -s -static -static-libgcc -static-libstdc++ \
    -mconsole "challenge.cpp" -o "WinCheck.exe"

"$CXX" -std=c++17 -O0 -g -static -static-libgcc -static-libstdc++ \
    -mconsole "challenge.cpp" -o "WinCheck_debug.exe"

echo "[+] Built WinCheck.exe and WinCheck_debug.exe"
file "WinCheck.exe" "WinCheck_debug.exe"
