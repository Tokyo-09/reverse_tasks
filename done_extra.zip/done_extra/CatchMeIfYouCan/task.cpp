#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#define ID_BTN_FLAG    101
#define ID_STATIC_INFO 102

HWND hBtn, hStatic;
int btn_width = 120;
int btn_height = 35;
int attempts = 0;
WNDPROC origBtnProc;

// Subclassed button procedure - the button runs away from the cursor
LRESULT CALLBACK BtnSubclass(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    if (msg == WM_MOUSEMOVE) {
        attempts++;

        HWND hParent = GetParent(hwnd);
        RECT parentRect;
        GetClientRect(hParent, &parentRect);

        int newX = rand() % (parentRect.right - btn_width - 20) + 10;
        int newY = rand() % (parentRect.bottom - btn_height - 70) + 60;
        MoveWindow(hwnd, newX, newY, btn_width, btn_height, TRUE);

        char buf[128];
        snprintf(buf, sizeof(buf), "Too slow! Attempts: %d", attempts);
        SetWindowTextA(hStatic, buf);
        return 0;
    }
    return CallWindowProcA(origBtnProc, hwnd, msg, wParam, lParam);
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
        case WM_CREATE:
            srand((unsigned)time(NULL));

            hStatic = CreateWindowExA(0, "STATIC",
                "Click the button to get the flag.",
                WS_CHILD | WS_VISIBLE | SS_CENTER,
                10, 10, 380, 40, hwnd, (HMENU)ID_STATIC_INFO, NULL, NULL);

            hBtn = CreateWindowExA(0, "BUTTON", "Get Flag",
                WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
                140, 130, btn_width, btn_height, hwnd, (HMENU)ID_BTN_FLAG, NULL, NULL);

            // Subclass the button to intercept its messages
            origBtnProc = (WNDPROC)SetWindowLongPtrA(hBtn, GWLP_WNDPROC, (LONG_PTR)BtnSubclass);
            return 0;

        case WM_COMMAND:
            if (LOWORD(wParam) == ID_BTN_FLAG) {
                char buf[256];
                snprintf(buf, sizeof(buf),
                    "Flag: FLAG{Y0u_C4ught_Th3_Unt0uch4bl3}\n\nAttempts before success: %d",
                    attempts);
                MessageBoxA(hwnd, buf, "Congratulations!", MB_ICONINFORMATION);
            }
            return 0;

        case WM_DESTROY:
            PostQuitMessage(0);
            return 0;
    }
    return DefWindowProcA(hwnd, msg, wParam, lParam);
}

int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrev, LPSTR cmd, int nShow) {
    WNDCLASSEXA wc = {0};
    wc.cbSize = sizeof(WNDCLASSEXA);
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInst;
    wc.lpszClassName = "CatchMeIfYouCan";
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    RegisterClassExA(&wc);

    HWND hwnd = CreateWindowExA(0, "CatchMeIfYouCan", "Catch Me If You Can",
        WS_OVERLAPPEDWINDOW & ~WS_THICKFRAME & ~WS_MAXIMIZEBOX,
        CW_USEDEFAULT, CW_USEDEFAULT, 420, 320, NULL, NULL, hInst, NULL);

    ShowWindow(hwnd, nShow);
    UpdateWindow(hwnd);

    MSG msg;
    while (GetMessageA(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessageA(&msg);
    }
    return 0;
}
